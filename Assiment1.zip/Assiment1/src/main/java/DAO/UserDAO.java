package DAO;

import java.sql.*;

import org.mindrot.jbcrypt.BCrypt;

import Model.User;
import Utils.XJDBC;

public class UserDAO {

    // ===================== REGISTER ======================
	public boolean register(User u) throws Exception {
	    String sql = """
	        INSERT INTO Users (Password, Fullname, Birthday, Gender, Mobile, Email, Role)
	        VALUES (?, ?, ?, ?, ?, ?, ?)
	    """;

	    try (Connection conn = XJDBC.getConnection();
	         PreparedStatement ps = conn.prepareStatement(sql)) {

	        ps.setString(1, u.getPassword()); 
	        ps.setString(2, u.getFullname());
	        ps.setDate(3, u.getBirthday());
	        ps.setBoolean(4, u.isGender());
	        ps.setString(5, u.getMobile());
	        ps.setString(6, u.getEmail());
	        ps.setBoolean(7, u.isRole());

	        return ps.executeUpdate() > 0;
	    }
	}

    // ===================== LOGIN (EMAIL ONLY) ======================
	public User login(String email) throws Exception {

	    System.out.println("=== DEBUG LOGIN() ===");
	    System.out.println("Email nhận vào = " + email);

	    String sql = "SELECT * FROM Users WHERE Email = ?";

	    try (Connection con = XJDBC.getConnection();
	         PreparedStatement ps = con.prepareStatement(sql)) {

	        ps.setString(1, email);
	        System.out.println("SQL = " + sql);

	        ResultSet rs = ps.executeQuery();

	        if (!rs.next()) {
	            System.out.println("DEBUG: Không tìm thấy user nào với email này!");
	            return null;
	        }

	        // Nếu rs.next() == true → có user
	        System.out.println("DEBUG: Tìm thấy user trong DB!");

	        User u = map(rs);

	        // Debug toàn bộ thông tin lấy ra
	        System.out.println("DB_User_Id      = " + u.getId());
	        System.out.println("DB_User_Email   = " + u.getEmail());
	        System.out.println("DB_User_Pass    = " + u.getPassword());
	        System.out.println("DB_User_Full    = " + u.getFullname());
	        System.out.println("DB_User_Role    = " + u.isRole());

	        return u;
	    }
	}


    // ===================== FIND BY EMAIL ======================
    public User findByEmail(String email) throws Exception {
        String sql = "SELECT * FROM Users WHERE Email = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    private User map(ResultSet rs) throws Exception {
        User u = new User();
        u.setId(rs.getString("Id"));
        u.setPassword(rs.getString("Password"));
        u.setFullname(rs.getString("Fullname"));
        u.setBirthday(rs.getDate("Birthday"));
        u.setGender(rs.getBoolean("Gender"));
        u.setMobile(rs.getString("Mobile"));
        u.setEmail(rs.getString("Email"));
        u.setRole(rs.getBoolean("Role"));
        return u;
    }

    // ===================== MAP RESULTSET -> USER ======================
    private User mapUser(ResultSet rs) throws Exception {
        User u = new User();

        u.setId(rs.getString("Id"));
        u.setPassword(rs.getString("Password"));
        u.setFullname(rs.getString("Fullname"));
        u.setGender(rs.getBoolean("Gender"));
        u.setBirthday(rs.getDate("Birthday"));
        u.setMobile(rs.getString("Mobile"));
        u.setEmail(rs.getString("Email"));
        u.setRole(rs.getBoolean("Role"));

        return u;
    }
}
