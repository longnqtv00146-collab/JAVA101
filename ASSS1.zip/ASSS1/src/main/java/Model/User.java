package Model;

import java.util.Date;

public class User {
    private String id;
    private String username;
    private String password;
    private String fullname;
    private Date birthday;
    private boolean gender;
    private String mobile;
    private String email;
    private boolean role;  // true = Admin, false = Phóng viên
    private boolean newsletters;
    
    // Constructors
    public User() {
    }
    
    // Getters and Setters
    public String getId() {
        return id;
    }
    
    public void setId(String id) {
        this.id = id;
    }
    
    public String getUsername() {
        return username;
    }
    
    public void setUsername(String username) {
        this.username = username;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getFullname() {
        return fullname;
    }
    
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }
    
    public Date getBirthday() {
        return birthday;
    }
    
    public void setBirthday(Date birthday) {
        this.birthday = birthday;
    }
    
    public boolean isGender() {
        return gender;
    }
    
    public void setGender(boolean gender) {
        this.gender = gender;
    }
    
    public String getMobile() {
        return mobile;
    }
    
    public void setMobile(String mobile) {
        this.mobile = mobile;
    }
    
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public boolean isRole() {
        return role;
    }
    
    public void setRole(boolean role) {
        this.role = role;
    }
    
    public boolean isNewsletters() {
        return newsletters;
    }
    
    public void setNewsletters(boolean newsletters) {
        this.newsletters = newsletters;
    }
    
    // ⭐ THÊM METHOD NÀY
    /**
     * Kiểm tra có phải admin không
     * @return true nếu là admin
     */
    public boolean isAdmin() {
        return role;
    }
    
    /**
     * Kiểm tra có phải phóng viên không
     * @return true nếu là phóng viên
     */
    public boolean isReporter() {
        return !role;
    }
    
    /**
     * Lấy tên vai trò
     * @return "Admin" hoặc "Phóng viên"
     */
    public String getRoleName() {
        return role ? "Admin" : "Phóng viên";
    }
    
    /**
     * Lấy tên giới tính
     * @return "Nam" hoặc "Nữ"
     */
    public String getGenderName() {
        return gender ? "Nam" : "Nữ";
    }
}