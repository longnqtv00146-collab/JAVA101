package Model;

import java.util.Date;

public class Newsletter {
    private String email;
    private boolean enabled;  // true = còn hiệu lực
    private Date subscribedDate;
    
    // Constructors
    public Newsletter() {
        this.enabled = true;
        this.subscribedDate = new Date();
    }
    
    public Newsletter(String email, boolean enabled) {
        this.email = email;
        this.enabled = enabled;
        this.subscribedDate = new Date();
    }
    
    // Getters and Setters
    public String getEmail() {
        return email;
    }
    
    public void setEmail(String email) {
        this.email = email;
    }
    
    public boolean isEnabled() {
        return enabled;
    }
    
    public void setEnabled(boolean enabled) {
        this.enabled = enabled;
    }
    
    public Date getSubscribedDate() {
        return subscribedDate;
    }
    
    public void setSubscribedDate(Date subscribedDate) {
        this.subscribedDate = subscribedDate;
    }
    
    // Helper methods
    public String getStatusText() {
        return enabled ? "Đang hoạt động" : "Đã hủy";
    }
    
    public String getStatusBadge() {
        return enabled ? "success" : "secondary";
    }
}