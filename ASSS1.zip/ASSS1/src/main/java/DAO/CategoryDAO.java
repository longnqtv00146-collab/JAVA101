package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Model.Category;
import Utils.XJDBC;

public class CategoryDAO {

    /**
     * Lấy tất cả danh mục
     */
    public List<Category> findAll() {
        List<Category> list = new ArrayList<>();
        String sql = "SELECT Id, Name FROM Categories";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Category c = new Category();
                c.setId(rs.getString("Id"));
                c.setName(rs.getString("Name"));
                list.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
    
    /**
     * Alias cho findAll() - để dễ đọc code
     */
    public List<Category> getAllCategories() {
        return findAll();
    }
    
    /**
     * Lấy danh mục theo ID
     */
    public Category getById(String id) {
        String sql = "SELECT Id, Name FROM Categories WHERE Id = ?";
        
        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                Category c = new Category();
                c.setId(rs.getString("Id"));
                c.setName(rs.getString("Name"));
                return c;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return null;
    }
    
    /**
     * Kiểm tra danh mục có tồn tại không
     */
    public boolean exists(String id) {
        String sql = "SELECT COUNT(*) AS total FROM Categories WHERE Id = ?";
        
        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("total") > 0;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Thêm danh mục mới
     */
    public boolean insert(Category category) {
        String sql = "INSERT INTO Categories (Id, Name) VALUES (?, ?)";
        
        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, category.getId());
            ps.setString(2, category.getName());
            
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Cập nhật danh mục
     */
    public boolean update(Category category) {
        String sql = "UPDATE Categories SET Name = ? WHERE Id = ?";
        
        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, category.getName());
            ps.setString(2, category.getId());
            
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Xóa danh mục
     */
    public boolean delete(String id) {
        String sql = "DELETE FROM Categories WHERE Id = ?";
        
        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            
            ps.setString(1, id);
            
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }
    
    /**
     * Đếm tổng số danh mục
     */
    public int getTotalCategories() {
        String sql = "SELECT COUNT(*) AS total FROM Categories";
        
        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }
}