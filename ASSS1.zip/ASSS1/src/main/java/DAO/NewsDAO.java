package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Model.News;
import Utils.XJDBC;

public class NewsDAO {

    // ================================
    // 1) TIN TRANG CHỦ (Home = 1)
    // ================================
    public List<News> getHomeNews() {
        List<News> list = new ArrayList<>();
        String sql = """
            SELECT TOP 10 * 
            FROM News 
            WHERE Home = 1 
            ORDER BY PostedDate DESC
        """;

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(toEntity(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ================================
    // 2) LẤY THEO ID
    // ================================
    public News getById(String id) {
        String sql = "SELECT * FROM News WHERE Id = ?";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);

            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return toEntity(rs);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
    
    // ================================
    // 2.1) LẤY THEO ID (ALIAS)
    // ================================
    public News getNewsById(String id) {
        return getById(id);
    }

    // ================================
    // 3) LẤY THEO LOẠI
    // ================================
    public List<News> getByCategory(String cateId) {
        List<News> list = new ArrayList<>();
        String sql = """
            SELECT * 
            FROM News 
            WHERE CategoryId = ? 
            ORDER BY PostedDate DESC
        """;

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, cateId);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) list.add(toEntity(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ================================
    // 4) TOP HOT VIEW
    // ================================
    public List<News> getTopHot(int limit) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT TOP " + limit + " * FROM News ORDER BY ViewCount DESC";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(toEntity(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ================================
    // 4.1) TOP VIEWED NEWS (ALIAS FOR DASHBOARD)
    // ================================
    public List<News> getTopViewedNews(int limit) {
        return getTopHot(limit);
    }

    // ================================
    // 5) TOP MỚI NHẤT
    // ================================
    public List<News> getLatest(int limit) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT TOP " + limit + " * FROM News ORDER BY PostedDate DESC";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) list.add(toEntity(rs));

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }

    // ================================
    // 5.1) LATEST NEWS (ALIAS FOR DASHBOARD)
    // ================================
    public List<News> getLatestNews(int limit) {
        return getLatest(limit);
    }

    // ================================
    // 6) TIN LIÊN QUAN
    // ================================
    public List<News> getRelated(String categoryId, String excludeId, int limit) {
        List<News> list = new ArrayList<>();
        
        String sql = "SELECT TOP (?) * FROM News " +
                     "WHERE CategoryId = ? AND Id != ? " +
                     "ORDER BY PostedDate DESC";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ps.setString(2, categoryId);
            ps.setString(3, excludeId);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 7) TĂNG LƯỢT XEM
    // ================================
    public void increaseViews(String id) {
        String sql = "UPDATE News SET ViewCount = ViewCount + 1 WHERE Id = ?";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, id);
            ps.executeUpdate();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    // ================================
    // 8) LẤY TIN THEO AUTHOR ID (CHO PHÓNG VIÊN)
    // ================================
    public List<News> getNewsByAuthorId(String authorId) {
        List<News> list = new ArrayList<>();
        String sql = "SELECT * FROM News WHERE AuthorId = ? ORDER BY PostedDate DESC";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, authorId);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 9) THÊM TIN MỚI (CHO PHÓNG VIÊN)
    // ================================
    public boolean addNews(News news) {
        String sql = """
            INSERT INTO News (Id, Title, Content, Image, PostedDate, Author, AuthorId, CategoryId, Home, ViewCount)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 0)
        """;
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            // Generate ID nếu chưa có
            if (news.getId() == null || news.getId().isEmpty()) {
                news.setId("N" + System.currentTimeMillis());
            }
            
            ps.setString(1, news.getId());
            ps.setString(2, news.getTitle());
            ps.setString(3, news.getContent());
            ps.setString(4, news.getImage());
            ps.setDate(5, news.getPostedDate());
            ps.setString(6, news.getAuthor());
            ps.setString(7, news.getAuthorId());
            ps.setString(8, news.getCategoryId());
            ps.setBoolean(9, news.isHome());
            
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ================================
    // 10) CẬP NHẬT TIN (CHO PHÓNG VIÊN)
    // ================================
    public boolean updateNews(News news) {
        String sql = """
            UPDATE News 
            SET Title = ?, Content = ?, Image = ?, CategoryId = ?, Home = ?
            WHERE Id = ?
        """;
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, news.getTitle());
            ps.setString(2, news.getContent());
            ps.setString(3, news.getImage());
            ps.setString(4, news.getCategoryId());
            ps.setBoolean(5, news.isHome());
            ps.setString(6, news.getId());
            
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ================================
    // 11) XÓA TIN (CHO PHÓNG VIÊN)
    // ================================
    public boolean deleteNews(String id) {
        String sql = "DELETE FROM News WHERE Id = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, id);
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ================================
    // 12) LẤY TẤT CẢ TIN (CHO ADMIN)
    // ================================
    public List<News> getAllNews() {
        List<News> list = new ArrayList<>();
        String sql = "SELECT * FROM News ORDER BY PostedDate DESC";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 13) ĐẾM TỔNG SỐ TIN
    // ================================
    public int getTotalNews() {
        String sql = "SELECT COUNT(*) AS total FROM News";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }
    
    // ================================
    // 14) ĐẾM TIN THEO AUTHOR
    // ================================
    public int countNewsByAuthor(String authorId) {
        String sql = "SELECT COUNT(*) AS total FROM News WHERE AuthorId = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, authorId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }

    // ================================
    // 15) TÌM KIẾM TIN (CHO ADMIN)
    // ================================
    public List<News> searchNews(String keyword) {
        List<News> list = new ArrayList<>();
        String sql = """
            SELECT * FROM News 
            WHERE Title LIKE ? OR Content LIKE ? OR Author LIKE ?
            ORDER BY PostedDate DESC
        """;
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            String searchPattern = "%" + keyword + "%";
            ps.setString(1, searchPattern);
            ps.setString(2, searchPattern);
            ps.setString(3, searchPattern);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 16) LẤY TIN THEO NGÀY (CHO BÁO CÁO)
    // ================================
    public List<News> getNewsByDateRange(Date startDate, Date endDate) {
        List<News> list = new ArrayList<>();
        String sql = """
            SELECT * FROM News 
            WHERE PostedDate BETWEEN ? AND ?
            ORDER BY PostedDate DESC
        """;
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setDate(1, startDate);
            ps.setDate(2, endDate);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 17) ĐẾM TIN THEO LOẠI
    // ================================
    public int countNewsByCategory(String categoryId) {
        String sql = "SELECT COUNT(*) AS total FROM News WHERE CategoryId = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoryId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }

    // ================================
    // 18) LẤY TOP TIN TRANG CHỦ (CHO DASHBOARD)
    // ================================
    public List<News> getTopHomeNews(int limit) {
        List<News> list = new ArrayList<>();
        String sql = """
            SELECT TOP (?) * FROM News 
            WHERE Home = 1 
            ORDER BY PostedDate DESC
        """;
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 19) ĐẾM TIN TRANG CHỦ
    // ================================
    public int countHomeNews() {
        String sql = "SELECT COUNT(*) AS total FROM News WHERE Home = 1";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }

    // ================================
    // 20) LẤY TIN MỚI NHẤT THEO LOẠI
    // ================================
    public List<News> getLatestNewsByCategory(String categoryId, int limit) {
        List<News> list = new ArrayList<>();
        String sql = """
            SELECT TOP (?) * FROM News 
            WHERE CategoryId = ? 
            ORDER BY PostedDate DESC
        """;
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setInt(1, limit);
            ps.setString(2, categoryId);
            
            ResultSet rs = ps.executeQuery();
            
            while (rs.next()) {
                list.add(toEntity(rs));
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return list;
    }

    // ================================
    // 21) KIỂM TRA TIN TỒN TẠI
    // ================================
    public boolean exists(String id) {
        String sql = "SELECT COUNT(*) FROM News WHERE Id = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return false;
    }

    // ================================
    // 22) CẬP NHẬT TRẠNG THÁI HOME
    // ================================
    public boolean updateHomeStatus(String id, boolean home) {
        String sql = "UPDATE News SET Home = ? WHERE Id = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setBoolean(1, home);
            ps.setString(2, id);
            
            return ps.executeUpdate() > 0;
            
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // ================================
    // 23) LẤY THỐNG KÊ VIEW THEO LOẠI
    // ================================
    public int getTotalViewsByCategory(String categoryId) {
        String sql = "SELECT SUM(ViewCount) AS totalViews FROM News WHERE CategoryId = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, categoryId);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt("totalViews");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }

    // ================================
    // MAP RESULTSET -> NEWS
    // ================================
    private News toEntity(ResultSet rs) throws Exception {
        News n = new News();
        n.setId(rs.getString("Id"));
        n.setTitle(rs.getString("Title"));
        n.setContent(rs.getString("Content"));
        n.setImage(rs.getString("Image"));
        n.setPostedDate(rs.getDate("PostedDate"));
        n.setAuthor(rs.getString("Author"));
        n.setViewCount(rs.getInt("ViewCount"));
        n.setCategoryId(rs.getString("CategoryId"));
        n.setHome(rs.getBoolean("Home"));
        
        // Set AuthorId từ cột AuthorId
        String authorId = rs.getString("AuthorId");
        n.setAuthorId(authorId != null ? authorId : rs.getString("Author"));
        
        return n;
    }
 // ================================
 // THÊM CÁC PHƯƠNG THỨC SAU VÀO NewsDAO.java
 // (Thêm vào cuối file, trước dòng cuối cùng })
 // ================================

     // ================================
     // 24) TỔNG LƯỢT XEM CỦA TÁC GIẢ
     // ================================
     public int getTotalViewsByAuthor(String authorId) {
         String sql = "SELECT COALESCE(SUM(ViewCount), 0) AS total FROM News WHERE AuthorId = ?";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ResultSet rs = ps.executeQuery();
             
             if (rs.next()) {
                 return rs.getInt("total");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return 0;
     }

     // ================================
     // 25) ĐẾM TIN TRANG CHỦ CỦA TÁC GIẢ
     // ================================
     public int countHomeNewsByAuthor(String authorId) {
         String sql = "SELECT COUNT(*) AS total FROM News WHERE AuthorId = ? AND Home = 1";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ResultSet rs = ps.executeQuery();
             
             if (rs.next()) {
                 return rs.getInt("total");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return 0;
     }

     // ================================
     // 26) NGÀY ĐĂNG TIN ĐẦU TIÊN CỦA TÁC GIẢ
     // ================================
     public Date getFirstNewsDateByAuthor(String authorId) {
         String sql = "SELECT MIN(PostedDate) AS firstDate FROM News WHERE AuthorId = ?";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ResultSet rs = ps.executeQuery();
             
             if (rs.next()) {
                 return rs.getDate("firstDate");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return null;
     }

     // ================================
     // 27) TIN MỚI NHẤT CỦA TÁC GIẢ
     // ================================
     public List<News> getRecentNewsByAuthor(String authorId, int limit) {
         List<News> list = new ArrayList<>();
         String sql = "SELECT TOP (?) * FROM News WHERE AuthorId = ? ORDER BY PostedDate DESC";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, limit);
             ps.setString(2, authorId);
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 list.add(toEntity(rs));
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return list;
     }

     // ================================
     // 28) ĐẾM TIN THEO TÁC GIẢ TRONG THÁNG
     // ================================
     public int countNewsByAuthorInMonth(String authorId, int month, int year) {
         String sql = """
             SELECT COUNT(*) AS total FROM News 
             WHERE AuthorId = ? 
             AND MONTH(PostedDate) = ? 
             AND YEAR(PostedDate) = ?
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ps.setInt(2, month);
             ps.setInt(3, year);
             ResultSet rs = ps.executeQuery();
             
             if (rs.next()) {
                 return rs.getInt("total");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return 0;
     }

     // ================================
     // 29) THỐNG KÊ THEO DANH MỤC CỦA TÁC GIẢ
     // ================================
     public List<java.util.Map<String, Object>> getCategoryStatsByAuthor(String authorId) {
         List<java.util.Map<String, Object>> stats = new ArrayList<>();
         
         // ⚠️ QUAN TRỌNG: Kiểm tra tên bảng Category trong DB của bạn
         // Có thể là: Category, Categories, Loai, hoặc tên khác
         // Thay đổi tên bảng cho phù hợp
         
         String sql = """
             SELECT 
                 ISNULL(c.Name, 'Chưa phân loại') AS categoryName, 
                 COUNT(n.Id) AS count 
             FROM News n 
             LEFT JOIN Categories c ON n.CategoryId = c.Id 
             WHERE n.AuthorId = ? 
             GROUP BY c.Name 
             ORDER BY count DESC
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 java.util.Map<String, Object> stat = new java.util.HashMap<>();
                 stat.put("categoryName", rs.getString("categoryName"));
                 stat.put("count", rs.getInt("count"));
                 stats.add(stat);
             }
             
         } catch (Exception e) {
             System.err.println("❌ Lỗi getCategoryStatsByAuthor: " + e.getMessage());
             e.printStackTrace();
             
             // FALLBACK: Trả về thống kê cơ bản không cần JOIN
             return getCategoryStatsBasic(authorId);
         }
         
         return stats;
     }
     
     private List<java.util.Map<String, Object>> getCategoryStatsBasic(String authorId) {
         List<java.util.Map<String, Object>> stats = new ArrayList<>();
         
         String sql = """
             SELECT 
                 CategoryId AS categoryName, 
                 COUNT(*) AS count 
             FROM News 
             WHERE AuthorId = ? 
             GROUP BY CategoryId 
             ORDER BY count DESC
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 java.util.Map<String, Object> stat = new java.util.HashMap<>();
                 stat.put("categoryName", rs.getString("categoryName"));
                 stat.put("count", rs.getInt("count"));
                 stats.add(stat);
             }
             
         } catch (Exception e) {
             System.err.println("❌ Lỗi getCategoryStatsBasic: " + e.getMessage());
         }
         
         return stats;
     }

     // ================================
     // 30) TOP TIN XEM NHIỀU NHẤT CỦA TÁC GIẢ
     // ================================
     public List<News> getTopViewedNewsByAuthor(String authorId, int limit) {
         List<News> list = new ArrayList<>();
         
         String sql = """
             SELECT TOP (?) n.*, ISNULL(c.Name, 'Chưa phân loại') AS categoryName 
             FROM News n 
             LEFT JOIN Categories c ON n.CategoryId = c.Id 
             WHERE n.AuthorId = ? 
             ORDER BY n.ViewCount DESC
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, limit);
             ps.setString(2, authorId);
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 News news = toEntity(rs);
                 // Thêm categoryName nếu có
                 try {
                     news.setCategoryName(rs.getString("categoryName"));
                 } catch (SQLException e) {
                     news.setCategoryName("Chưa phân loại");
                 }
                 list.add(news);
             }
             
         } catch (Exception e) {
             System.err.println("❌ Lỗi getTopViewedNewsByAuthor: " + e.getMessage());
             e.printStackTrace();
             
             // FALLBACK: Lấy tin không JOIN
             return getTopViewedNewsByAuthorBasic(authorId, limit);
         }
         
         return list;
     }
     
     
     private List<News> getTopViewedNewsByAuthorBasic(String authorId, int limit) {
         List<News> list = new ArrayList<>();
         
         String sql = """
             SELECT TOP (?) * FROM News 
             WHERE AuthorId = ? 
             ORDER BY ViewCount DESC
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, limit);
             ps.setString(2, authorId);
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 News news = toEntity(rs);
                 news.setCategoryName(news.getCategoryId()); // Hiển thị ID thay vì name
                 list.add(news);
             }
             
         } catch (Exception e) {
             System.err.println("❌ Lỗi getTopViewedNewsByAuthorBasic: " + e.getMessage());
         }
         
         return list;
     }

     // ================================
     // 31) TỔNG LƯỢT XEM TẤT CẢ TIN
     // ================================
     public int getTotalViews() {
         String sql = "SELECT COALESCE(SUM(ViewCount), 0) AS total FROM News";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql);
              ResultSet rs = ps.executeQuery()) {
             
             if (rs.next()) {
                 return rs.getInt("total");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return 0;
     }

     // ================================
     // 32) TIN THEO TÁC GIẢ VỚI PHÂN TRANG
     // ================================
     public List<News> getNewsByAuthorWithPagination(String authorId, int page, int pageSize) {
         List<News> list = new ArrayList<>();
         int offset = (page - 1) * pageSize;
         
         String sql = """
             SELECT * FROM News 
             WHERE AuthorId = ? 
             ORDER BY PostedDate DESC 
             OFFSET ? ROWS 
             FETCH NEXT ? ROWS ONLY
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, authorId);
             ps.setInt(2, offset);
             ps.setInt(3, pageSize);
             
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 list.add(toEntity(rs));
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return list;
     }

     // ================================
     // 33) TẤT CẢ TIN VỚI PHÂN TRANG (CHO ADMIN)
     // ================================
     public List<News> getAllNewsWithPagination(int page, int pageSize) {
         List<News> list = new ArrayList<>();
         int offset = (page - 1) * pageSize;
         
         String sql = """
             SELECT * FROM News 
             ORDER BY PostedDate DESC 
             OFFSET ? ROWS 
             FETCH NEXT ? ROWS ONLY
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, offset);
             ps.setInt(2, pageSize);
             
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 list.add(toEntity(rs));
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return list;
     }

     // ================================
     // 34) ĐẾM TIN TRONG THÁNG (DASHBOARD)
     // ================================
     public int countNewsInMonth(int month, int year) {
         String sql = """
             SELECT COUNT(*) AS total FROM News 
             WHERE MONTH(PostedDate) = ? 
             AND YEAR(PostedDate) = ?
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, month);
             ps.setInt(2, year);
             ResultSet rs = ps.executeQuery();
             
             if (rs.next()) {
                 return rs.getInt("total");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return 0;
     }

     // ================================
     // 35) ĐẾM TIN HÔM NAY
     // ================================
     public int countNewsToday() {
         String sql = """
             SELECT COUNT(*) AS total FROM News 
             WHERE CAST(PostedDate AS DATE) = CAST(GETDATE() AS DATE)
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql);
              ResultSet rs = ps.executeQuery()) {
             
             if (rs.next()) {
                 return rs.getInt("total");
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return 0;
     }

     // ================================
     // 36) TIN THEO NHIỀU DANH MỤC
     // ================================
     public List<News> getNewsByCategories(List<String> categoryIds, int limit) {
         if (categoryIds == null || categoryIds.isEmpty()) {
             return new ArrayList<>();
         }
         
         List<News> list = new ArrayList<>();
         
         // Tạo placeholders: ?,?,?
         String placeholders = String.join(",", 
             java.util.Collections.nCopies(categoryIds.size(), "?"));
         
         String sql = "SELECT TOP (?) * FROM News WHERE CategoryId IN (" + placeholders + 
                      ") ORDER BY PostedDate DESC";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, limit);
             for (int i = 0; i < categoryIds.size(); i++) {
                 ps.setString(i + 2, categoryIds.get(i));
             }
             
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 list.add(toEntity(rs));
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return list;
     }

     // ================================
     // 37) XÓA TIN THEO DANH MỤC (ADMIN)
     // ================================
     public int deleteNewsByCategory(String categoryId) {
         String sql = "DELETE FROM News WHERE CategoryId = ?";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, categoryId);
             return ps.executeUpdate();
             
         } catch (Exception e) {
             e.printStackTrace();
             return 0;
         }
     }

     // ================================
     // 38) CẬP NHẬT DANH MỤC CHO NHIỀU TIN
     // ================================
     public boolean updateCategoryForNews(List<String> newsIds, String newCategoryId) {
         if (newsIds == null || newsIds.isEmpty()) {
             return false;
         }
         
         String placeholders = String.join(",", 
             java.util.Collections.nCopies(newsIds.size(), "?"));
         
         String sql = "UPDATE News SET CategoryId = ? WHERE Id IN (" + placeholders + ")";
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setString(1, newCategoryId);
             for (int i = 0; i < newsIds.size(); i++) {
                 ps.setString(i + 2, newsIds.get(i));
             }
             
             return ps.executeUpdate() > 0;
             
         } catch (Exception e) {
             e.printStackTrace();
             return false;
         }
     }

     // ================================
     // 39) THỐNG KÊ TIN THEO THÁNG (12 THÁNG GẦN NHẤT)
     // ================================
     public List<java.util.Map<String, Object>> getMonthlyNewsStats(int months) {
         List<java.util.Map<String, Object>> stats = new ArrayList<>();
         
         String sql = """
             SELECT 
                 YEAR(PostedDate) AS year,
                 MONTH(PostedDate) AS month,
                 COUNT(*) AS count,
                 SUM(ViewCount) AS totalViews
             FROM News
             WHERE PostedDate >= DATEADD(MONTH, -?, GETDATE())
             GROUP BY YEAR(PostedDate), MONTH(PostedDate)
             ORDER BY YEAR(PostedDate) DESC, MONTH(PostedDate) DESC
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql)) {
             
             ps.setInt(1, months);
             ResultSet rs = ps.executeQuery();
             
             while (rs.next()) {
                 java.util.Map<String, Object> stat = new java.util.HashMap<>();
                 stat.put("year", rs.getInt("year"));
                 stat.put("month", rs.getInt("month"));
                 stat.put("count", rs.getInt("count"));
                 stat.put("totalViews", rs.getInt("totalViews"));
                 stats.add(stat);
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return stats;
     }

     // ================================
     // 40) THỐNG KÊ TỔNG QUAN (DASHBOARD)
     // ================================
     public java.util.Map<String, Integer> getOverviewStats() {
         java.util.Map<String, Integer> stats = new java.util.HashMap<>();
         
         String sql = """
             SELECT 
                 COUNT(*) AS totalNews,
                 SUM(ViewCount) AS totalViews,
                 SUM(CASE WHEN Home = 1 THEN 1 ELSE 0 END) AS homeNews,
                 COUNT(DISTINCT AuthorId) AS totalAuthors,
                 COUNT(DISTINCT CategoryId) AS totalCategories
             FROM News
         """;
         
         try (Connection conn = XJDBC.getConnection();
              PreparedStatement ps = conn.prepareStatement(sql);
              ResultSet rs = ps.executeQuery()) {
             
             if (rs.next()) {
                 stats.put("totalNews", rs.getInt("totalNews"));
                 stats.put("totalViews", rs.getInt("totalViews"));
                 stats.put("homeNews", rs.getInt("homeNews"));
                 stats.put("totalAuthors", rs.getInt("totalAuthors"));
                 stats.put("totalCategories", rs.getInt("totalCategories"));
             }
             
         } catch (Exception e) {
             e.printStackTrace();
         }
         
         return stats;
     }
}