package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import Model.Newsletter;
import Utils.XJDBC;

public class NewsletterDAO {

    // Thêm email đăng ký nhận tin
    public boolean insert(String email) {
        String sql = "INSERT INTO Newsletters (Email, Enabled) VALUES (?, 1)";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Kiểm tra email có tồn tại chưa
    public boolean exists(String email) {
        String sql = "SELECT Email FROM Newsletters WHERE Email = ?";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);

            try (ResultSet rs = ps.executeQuery()) {
                return rs.next();
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Vô hiệu hóa email (unsubscribe)
    public boolean disable(String email) {
        String sql = "UPDATE Newsletters SET Enabled = 0 WHERE Email = ?";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            return ps.executeUpdate() > 0;

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    // Map ResultSet về model
    private Newsletter map(ResultSet rs) throws Exception {
        Newsletter n = new Newsletter();
        n.setEmail(rs.getString("Email"));
        n.setEnabled(rs.getBoolean("Enabled"));
        return n;
    }
    
    public List<Newsletter> getAllNewsletters() throws Exception {
        List<Newsletter> newsletters = new ArrayList<>();
        
        String sql = "SELECT Email, Enabled FROM Newsletters";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                Newsletter newsletter = new Newsletter();
                newsletter.setEmail(rs.getString("Email"));
                newsletter.setEnabled(rs.getBoolean("Enabled"));
                newsletters.add(newsletter);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return newsletters;
    }
    
    /**
     * ✅ FIXED: Lấy danh sách email đang active (enabled = 1)
     * Đổi từ "true" sang "1" cho SQL Server
     */
    public List<String> getActiveEmails() throws Exception {
        List<String> emails = new ArrayList<>();
        
        // ✅ SQL Server: Dùng 1 thay vì true
        String sql = "SELECT Email FROM Newsletters WHERE Enabled = 1";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            while (rs.next()) {
                String email = rs.getString("Email");
                if (email != null && !email.trim().isEmpty()) {
                    emails.add(email);
                }
            }
            
        } catch (SQLException e) {
            System.err.println("❌ Lỗi khi lấy danh sách email: " + e.getMessage());
            e.printStackTrace();
        }
        
        return emails;
    }
    
    /**
     * ✅ FIXED: Đăng ký nhận newsletter
     * SQL Server không hỗ trợ ON DUPLICATE KEY UPDATE
     */
    public boolean subscribe(String email) throws Exception {
        // Kiểm tra xem email đã tồn tại chưa
        if (exists(email)) {
            // Nếu có rồi, update Enabled = 1
            String sql = "UPDATE Newsletters SET Enabled = 1 WHERE Email = ?";
            
            try (Connection conn = XJDBC.getConnection();
                 PreparedStatement ps = conn.prepareStatement(sql)) {
                
                ps.setString(1, email);
                return ps.executeUpdate() > 0;
            }
        } else {
            // Nếu chưa có, insert mới
            return insert(email);
        }
    }
    
    /**
     * ✅ FIXED: Hủy đăng ký newsletter
     * Đổi từ "false" sang "0"
     */
    public boolean unsubscribe(String email) throws Exception {
        String sql = "UPDATE Newsletters SET Enabled = 0 WHERE Email = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Xóa email khỏi danh sách
     */
    public boolean deleteNewsletter(String email) throws Exception {
        String sql = "DELETE FROM Newsletters WHERE Email = ?";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            return ps.executeUpdate() > 0;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * ✅ FIXED: Kiểm tra email đã đăng ký chưa
     * Đổi từ "true" sang "1"
     */
    public boolean isSubscribed(String email) throws Exception {
        String sql = "SELECT * FROM Newsletters WHERE Email = ? AND Enabled = 1";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {
            
            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            
            boolean result = rs.next();
            rs.close();
            return result;
            
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
    
    /**
     * Đếm tổng số subscribers (active)
     */
    public int getActiveSubscriberCount() {
        String sql = "SELECT COUNT(*) AS total FROM Newsletters WHERE Enabled = 1";
        
        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            
            if (rs.next()) {
                return rs.getInt("total");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
        
        return 0;
    }
}