package DAO;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

import org.mindrot.jbcrypt.BCrypt;

import Model.User;
import Utils.XJDBC;

public class UserDAO {

    // ===================== REGISTER ======================
    public boolean register(User u) throws Exception {
        String sql = """
            INSERT INTO Users (Password, Fullname, Birthday, Gender, Mobile, Email, Role)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getPassword()); 
            ps.setString(2, u.getFullname());
            ps.setDate(3, (Date) u.getBirthday());
            ps.setBoolean(4, u.isGender());
            ps.setString(5, u.getMobile());
            ps.setString(6, u.getEmail());
            ps.setBoolean(7, u.isRole());

            return ps.executeUpdate() > 0;
        }
    }

    // ===================== LOGIN (EMAIL ONLY) ======================
    public User login(String email) throws Exception {

        System.out.println("=== DEBUG LOGIN() ===");
        System.out.println("Email nhận vào = " + email);

        String sql = "SELECT * FROM Users WHERE Email = ?";

        try (Connection con = XJDBC.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, email);
            System.out.println("SQL = " + sql);

            ResultSet rs = ps.executeQuery();

            if (!rs.next()) {
                System.out.println("DEBUG: Không tìm thấy user nào với email này!");
                return null;
            }

            // Nếu rs.next() == true → có user
            System.out.println("DEBUG: Tìm thấy user trong DB!");

            User u = map(rs);

            // Debug toàn bộ thông tin lấy ra
            System.out.println("DB_User_Id      = " + u.getId());
            System.out.println("DB_User_Email   = " + u.getEmail());
            System.out.println("DB_User_Pass    = " + u.getPassword());
            System.out.println("DB_User_Full    = " + u.getFullname());
            System.out.println("DB_User_Role    = " + u.isRole());

            return u;
        }
    }

    // ===================== FIND BY EMAIL ======================
    public User findByEmail(String email) throws Exception {
        String sql = "SELECT * FROM Users WHERE Email = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, email);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) return map(rs);
        }
        return null;
    }

    // ===================== GET USER BY ID (for Admin) ======================
    public User getUserById(String id) throws Exception {
        String sql = "SELECT * FROM Users WHERE Id = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return map(rs);
            }
        }
        return null;
    }

    // ===================== GET ALL USERS (for Admin) ======================
    public List<User> getAllUsers() throws Exception {
        List<User> users = new ArrayList<>();
        String sql = "SELECT * FROM Users ORDER BY Role DESC, Fullname ASC";

        try (Connection conn = XJDBC.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                users.add(map(rs));
            }
        }
        
        return users;
    }

    // ===================== INSERT NEW USER (for Admin) ======================
    public boolean insert(User u) throws Exception {
        String sql = """
            INSERT INTO Users (Password, Fullname, Birthday, Gender, Mobile, Email, Role)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        """;

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getPassword()); 
            ps.setString(2, u.getFullname());
            ps.setDate(3, u.getBirthday() != null ? new Date(u.getBirthday().getTime()) : null);
            ps.setBoolean(4, u.isGender());
            ps.setString(5, u.getMobile());
            ps.setString(6, u.getEmail());
            ps.setBoolean(7, u.isRole());

            return ps.executeUpdate() > 0;
        }
    }


    // ===================== UPDATE USER (for Admin & User Profile) ======================
    public boolean update(User u) throws Exception {
        String sql = """
            UPDATE Users
            SET Password=?, Fullname=?, Birthday=?, Gender=?, Mobile=?, Email=?, Role=?
            WHERE Id=?
        """;

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getPassword());
            ps.setString(2, u.getFullname());
            ps.setDate(3, u.getBirthday() != null ? new Date(u.getBirthday().getTime()) : null);
            ps.setBoolean(4, u.isGender());
            ps.setString(5, u.getMobile());
            ps.setString(6, u.getEmail());
            ps.setBoolean(7, u.isRole());
            ps.setString(8, u.getId());

            return ps.executeUpdate() > 0;
        }
    }

    // ===================== DELETE USER (for Admin) ======================
    public boolean delete(String id) throws Exception {
        String sql = "DELETE FROM Users WHERE Id = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // ===================== CHECK IF USER EXISTS ======================
    public boolean exists(String id) throws Exception {
        String sql = "SELECT COUNT(*) FROM Users WHERE Id = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, id);
            ResultSet rs = ps.executeQuery();
            
            if (rs.next()) {
                return rs.getInt(1) > 0;
            }
        }
        return false;
    }

    // ===================== GET TOTAL USER COUNT ======================
    public int getTotalUsers() throws Exception {
        String sql = "SELECT COUNT(*) FROM Users";

        try (Connection conn = XJDBC.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // ===================== GET ADMIN COUNT ======================
    public int getAdminCount() throws Exception {
        String sql = "SELECT COUNT(*) FROM Users WHERE Role = 1";

        try (Connection conn = XJDBC.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // ===================== GET REPORTER COUNT ======================
    public int getReporterCount() throws Exception {
        String sql = "SELECT COUNT(*) FROM Users WHERE Role = 0";

        try (Connection conn = XJDBC.getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            if (rs.next()) {
                return rs.getInt(1);
            }
        }
        return 0;
    }

    // ===================== CHANGE PASSWORD ======================
    public boolean changePassword(String id, String newPassword) throws Exception {
        String sql = "UPDATE Users SET Password = ? WHERE Id = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, newPassword);
            ps.setString(2, id);

            return ps.executeUpdate() > 0;
        }
    }

    // ===================== TOGGLE USER ROLE (Admin ⇄ Reporter) ======================
    public boolean toggleRole(String id) throws Exception {
        String sql = "UPDATE Users SET Role = CASE WHEN Role = 1 THEN 0 ELSE 1 END WHERE Id = ?";

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, id);
            return ps.executeUpdate() > 0;
        }
    }

    // ===================== UPDATE PROFILE (without password) ======================
    public boolean updateProfile(User u) throws Exception {
        String sql = """
            UPDATE Users
            SET Fullname=?, Birthday=?, Gender=?, Mobile=?, Email=?
            WHERE Id=?
        """;

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            ps.setString(1, u.getFullname());
            ps.setDate(2, u.getBirthday() != null ? new Date(u.getBirthday().getTime()) : null);
            ps.setBoolean(3, u.isGender());
            ps.setString(4, u.getMobile());
            ps.setString(5, u.getEmail());
            ps.setString(6, u.getId());

            return ps.executeUpdate() > 0;
        }
    }

    // ===================== SEARCH USERS BY NAME OR EMAIL ======================
    public List<User> searchUsers(String keyword) throws Exception {
        List<User> users = new ArrayList<>();
        String sql = """
            SELECT * FROM Users 
            WHERE Fullname LIKE ? OR Email LIKE ? OR Id LIKE ?
            ORDER BY Role DESC, Fullname ASC
        """;

        try (Connection conn = XJDBC.getConnection();
             PreparedStatement ps = conn.prepareStatement(sql)) {

            String searchPattern = "%" + keyword + "%";
            ps.setString(1, searchPattern);
            ps.setString(2, searchPattern);
            ps.setString(3, searchPattern);

            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                users.add(map(rs));
            }
        }
        
        return users;
    }

    // ===================== MAP RESULTSET -> USER ======================
    private User map(ResultSet rs) throws Exception {
        User u = new User();
        u.setId(rs.getString("Id"));
        u.setPassword(rs.getString("Password"));
        u.setFullname(rs.getString("Fullname"));
        u.setBirthday(rs.getDate("Birthday"));
        u.setGender(rs.getBoolean("Gender"));
        u.setMobile(rs.getString("Mobile"));
        u.setEmail(rs.getString("Email"));
        u.setRole(rs.getBoolean("Role"));
        return u;
    }

    // ===================== MAP RESULTSET -> USER (Alias) ======================
    private User mapUser(ResultSet rs) throws Exception {
        return map(rs);
    }
}