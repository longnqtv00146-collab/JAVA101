package Filter;

import jakarta.servlet.*;
import jakarta.servlet.annotation.WebFilter;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

@WebFilter("/*")
public class AuthFilter implements Filter {

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest request = (HttpServletRequest) req;
        HttpServletResponse response = (HttpServletResponse) res;

        String path = request.getServletPath();
        Object user = request.getSession().getAttribute("user");

        // Đã login → không cho vào login / register
        if (user != null && (
                path.equals("/login.jsp") ||
                path.equals("/login") ||
                path.equals("/register.jsp") ||
                path.equals("/register") ||
                path.equals("/index.jsp")
        )) {
            response.sendRedirect("layout.jsp");  // quay lại trang chính
            return;
        }

        // Trang public
        boolean isPublic =
                path.equals("/login.jsp") ||
                path.equals("/login") ||
                path.equals("/register.jsp") ||
                path.equals("/register") ||
                path.endsWith(".css") ||
                path.endsWith(".js") ||
                path.endsWith(".png") ||
                path.endsWith(".jpg");

        chain.doFilter(req, res);
    }
}

