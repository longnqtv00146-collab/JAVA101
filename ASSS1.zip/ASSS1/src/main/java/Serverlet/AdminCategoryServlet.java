package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import DAO.CategoryDAO;
import DAO.NewsDAO;
import Model.Category;
import Model.User;

@WebServlet("/admin/categories")
public class AdminCategoryServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private CategoryDAO categoryDAO;
    private NewsDAO newsDAO;
    
    @Override
    public void init() throws ServletException {
        categoryDAO = new CategoryDAO();
        newsDAO = new NewsDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra đăng nhập và phân quyền admin
        User user = checkAdminAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                listCategories(request, response);
            } else {
                switch (action) {
                    case "add":
                        showAddForm(request, response);
                        break;
                    case "edit":
                        showEditForm(request, response);
                        break;
                    case "delete":
                        deleteCategory(request, response);
                        break;
                    case "list":
                        listCategories(request, response);
                        break;
                    default:
                        listCategories(request, response);
                        break;
                }
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        User user = checkAdminAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                doGet(request, response);
                return;
            }
            
            switch (action) {
                case "create":
                    createCategory(request, response);
                    break;
                case "update":
                    updateCategory(request, response);
                    break;
                default:
                    doGet(request, response);
                    break;
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }
    
    // ========================================
    // AUTHENTICATION
    // ========================================
    
    /**
     * Kiểm tra authentication và phân quyền admin
     */
    private User checkAdminAuthentication(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User user = (User) session.getAttribute("user");
        
        // Kiểm tra phải là admin (Role = true)
        if (!user.isRole()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return null;
        }
        
        return user;
    }
    
    // ========================================
    // LIST CATEGORIES
    // ========================================
    
    /**
     * Danh sách tất cả categories
     */
    private void listCategories(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<Category> categories = categoryDAO.getAllCategories();
            int totalCategories = categoryDAO.getTotalCategories();
            
            request.setAttribute("categories", categories);
            request.setAttribute("totalCategories", totalCategories);
            request.setAttribute("view", "/admin/categories-list.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Lỗi khi tải danh sách loại tin");
        }
    }
    
    // ========================================
    // ADD CATEGORY
    // ========================================
    
    /**
     * Form thêm category
     */
    private void showAddForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setAttribute("view", "/admin/category-add.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
    
    /**
     * Tạo category mới
     */
    private void createCategory(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            
            // Validate input
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("categories?action=add&error=empty_id");
                return;
            }
            
            if (name == null || name.trim().isEmpty()) {
                response.sendRedirect("categories?action=add&error=empty_name");
                return;
            }
            
            // Kiểm tra ID đã tồn tại chưa
            if (categoryDAO.exists(id.trim())) {
                response.sendRedirect("categories?action=add&error=id_exists");
                return;
            }
            
            // Tạo category
            Category category = new Category();
            category.setId(id.trim().toUpperCase()); // ID viết hoa
            category.setName(name.trim());
            
            boolean success = categoryDAO.insert(category);
            
            if (success) {
                response.sendRedirect("categories?success=created");
            } else {
                response.sendRedirect("categories?action=add&error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("categories?action=add&error=exception");
        }
    }
    
    // ========================================
    // EDIT CATEGORY
    // ========================================
    
    /**
     * Form sửa category
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("categories?error=invalid_id");
                return;
            }
            
            Category category = categoryDAO.getById(id);
            
            if (category == null) {
                response.sendRedirect("categories?error=not_found");
                return;
            }
            
            request.setAttribute("category", category);
            request.setAttribute("view", "/admin/category-edit.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("categories?error=invalid");
        }
    }
    
    /**
     * Cập nhật category
     */
    private void updateCategory(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            String name = request.getParameter("name");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("categories?error=invalid_id");
                return;
            }
            
            if (name == null || name.trim().isEmpty()) {
                response.sendRedirect("categories?action=edit&id=" + id + "&error=empty_name");
                return;
            }
            
            Category category = categoryDAO.getById(id);
            
            if (category == null) {
                response.sendRedirect("categories?error=not_found");
                return;
            }
            
            category.setName(name.trim());
            
            boolean success = categoryDAO.update(category);
            
            if (success) {
                response.sendRedirect("categories?success=updated");
            } else {
                response.sendRedirect("categories?action=edit&id=" + id + "&error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("categories?error=exception");
        }
    }
    
    // ========================================
    // DELETE CATEGORY
    // ========================================
    
    /**
     * Xóa category
     */
    private void deleteCategory(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("categories?error=invalid_id");
                return;
            }
            
            Category category = categoryDAO.getById(id);
            
            if (category == null) {
                response.sendRedirect("categories?error=not_found");
                return;
            }
            
            // Kiểm tra xem category có tin nào không
            List<Model.News> newsInCategory = newsDAO.getByCategory(id);
            
            if (newsInCategory != null && !newsInCategory.isEmpty()) {
                response.sendRedirect("categories?error=has_news&count=" + newsInCategory.size());
                return;
            }
            
            boolean success = categoryDAO.delete(id);
            
            if (success) {
                response.sendRedirect("categories?success=deleted");
            } else {
                response.sendRedirect("categories?error=cannotdelete");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("categories?error=exception");
        }
    }
    
    // ========================================
    // ERROR HANDLING
    // ========================================
    
    /**
     * Xử lý lỗi chung
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        
        e.printStackTrace();
        
        request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
        request.setAttribute("view", "/admin/error.jsp");
        
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
}