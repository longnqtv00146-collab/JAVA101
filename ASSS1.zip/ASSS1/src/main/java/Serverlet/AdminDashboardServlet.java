package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.List;

import DAO.NewsDAO;
import DAO.CategoryDAO;
import DAO.UserDAO;
import DAO.NewsletterDAO;
import Model.News;
import Model.User;

@WebServlet("/admin/dashboard")
public class AdminDashboardServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private NewsDAO newsDAO;
    private CategoryDAO categoryDAO;
    private UserDAO userDAO;
    private NewsletterDAO newsletterDAO;
    
    @Override
    public void init() throws ServletException {
        newsDAO = new NewsDAO();
        categoryDAO = new CategoryDAO();
        userDAO = new UserDAO();
        newsletterDAO = new NewsletterDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Check authentication
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return;
        }
        
        User user = (User) session.getAttribute("user");
        
        // Check admin role
        if (!user.isRole()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return;
        }
        
        try {
            // Get statistics
            int totalNews = newsDAO.getTotalNews();
            int totalCategories = categoryDAO.getTotalCategories();
            int totalUsers = userDAO.getTotalUsers();
            int totalSubscribers = newsletterDAO.getActiveSubscriberCount();
            
            // Get recent news (5 items)
            List<News> recentNews = newsDAO.getLatestNews(5);
            
            // Get top viewed news (5 items)
            List<News> topNews = newsDAO.getTopViewedNews(5);
            
            // Set attributes
            request.setAttribute("totalNews", totalNews);
            request.setAttribute("totalCategories", totalCategories);
            request.setAttribute("totalUsers", totalUsers);
            request.setAttribute("totalSubscribers", totalSubscribers);
            request.setAttribute("recentNews", recentNews);
            request.setAttribute("topNews", topNews);
            request.setAttribute("view", "/admin/dashboard.jsp");
            
            // Forward to layout
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Lỗi khi tải dashboard: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        doGet(request, response);
    }
}