package Serverlet;

import java.io.IOException;
import java.sql.Date;

import DAO.UserDAO;
import Model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/account")
public class AccountServlet extends BaseServlet {  // ← Kế thừa BaseServlet thay vì HttpServlet
    
    private UserDAO dao = new UserDAO();
    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        
        // Kiểm tra đã đăng nhập chưa
        User user = (User) req.getSession().getAttribute("user");
        if (user == null) {
            resp.sendRedirect("login.jsp");
            return;
        }
        
        // ============================================
        // LOAD DỮ LIỆU CHUNG (menu, sidebar)
        // ============================================
        loadCommonData(req);
        
        // ============================================
        // FORWARD ĐẾN LAYOUT
        // ============================================
        forwardToLayout(req, resp, "/views/account.jsp");
    }
    
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        
        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");
        
        // Kiểm tra đã đăng nhập chưa
        User u = (User) req.getSession().getAttribute("user");
        if (u == null) {
            resp.sendRedirect("login.jsp");
            return;
        }
        
        // ============================================
        // CẬP NHẬT THÔNG TIN
        // ============================================
        try {
            u.setFullname(req.getParameter("fullname"));
            u.setBirthday(Date.valueOf(req.getParameter("birthday")));
            u.setGender(Boolean.parseBoolean(req.getParameter("gender")));
            u.setMobile(req.getParameter("mobile"));
            u.setEmail(req.getParameter("email"));
            
            dao.update(u);
            
            // Cập nhật lại session
            req.getSession().setAttribute("user", u);
            
            req.setAttribute("message", "Cập nhật thông tin thành công!");
            
        } catch (Exception e) {
            e.printStackTrace();
            req.setAttribute("error", "Có lỗi xảy ra: " + e.getMessage());
        }
        
        // ============================================
        // LOAD DỮ LIỆU CHUNG VÀ HIỂN THỊ LẠI
        // ============================================
        loadCommonData(req);
        forwardToLayout(req, resp, "/views/account.jsp");
    }
}