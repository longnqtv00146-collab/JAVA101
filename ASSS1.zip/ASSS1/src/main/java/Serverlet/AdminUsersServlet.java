package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

import org.mindrot.jbcrypt.BCrypt;

import DAO.UserDAO;
import Model.User;

@WebServlet("/admin/users")
public class AdminUsersServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private UserDAO userDAO;
    
    @Override
    public void init() throws ServletException {
        userDAO = new UserDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        User user = checkAdminAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                listAllUsers(request, response);
            } else {
                switch (action) {
                    case "add":
                        showAddForm(request, response);
                        break;
                    case "edit":
                        showEditForm(request, response);
                        break;
                    case "delete":
                        deleteUser(request, response);
                        break;
                    case "toggle":
                        toggleUserRole(request, response);
                        break;
                    case "list":
                        listAllUsers(request, response);
                        break;
                    default:
                        listAllUsers(request, response);
                        break;
                }
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        User user = checkAdminAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                doGet(request, response);
                return;
            }
            
            switch (action) {
                case "create":
                    createUser(request, response);
                    break;
                case "update":
                    updateUser(request, response);
                    break;
                default:
                    doGet(request, response);
                    break;
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }
    
    // ========================================
    // AUTHENTICATION
    // ========================================
    
    private User checkAdminAuthentication(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User user = (User) session.getAttribute("user");
        
        if (!user.isRole()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return null;
        }
        
        return user;
    }
    
    // ========================================
    // LIST USERS
    // ========================================
    
    private void listAllUsers(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<User> users = userDAO.getAllUsers();
            int totalUsers = users.size();
            int adminCount = (int) users.stream().filter(User::isRole).count();
            int reporterCount = totalUsers - adminCount;
            
            request.setAttribute("users", users);
            request.setAttribute("totalUsers", totalUsers);
            request.setAttribute("adminCount", adminCount);
            request.setAttribute("reporterCount", reporterCount);
            request.setAttribute("view", "/admin/users-list.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
    
    // ========================================
    // ADD USER
    // ========================================
    
    private void showAddForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Tạo ID tự động
        String nextId = generateNextUserId();
        request.setAttribute("nextUserId", nextId);
        
        request.setAttribute("view", "/admin/user-add.jsp");
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
    
    /**
     * Tạo ID người dùng tiếp theo dựa trên số lượng user trong database
     * Format: 1, 2, 3, 4, 5...
     */
    private String generateNextUserId() {
        try {
            List<User> users = userDAO.getAllUsers();
            
            // Tìm số thứ tự cao nhất trong các ID hiện có
            int maxNumber = 0;
            for (User user : users) {
                String id = user.getId();
                // Kiểm tra ID có phải là số không
                if (id != null && id.matches("\\d+")) {
                    try {
                        int number = Integer.parseInt(id);
                        if (number > maxNumber) {
                            maxNumber = number;
                        }
                    } catch (NumberFormatException e) {
                        // Bỏ qua ID không phải số
                    }
                }
            }
            
            // Tạo ID mới với số thứ tự kế tiếp
            int nextNumber = maxNumber + 1;
            return String.valueOf(nextNumber);
            
        } catch (Exception e) {
            e.printStackTrace();
            // Nếu có lỗi, bắt đầu từ 1
            return "1";
        }
    }
    
    private void createUser(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        try {
            String id = generateNextUserId();

            // Lấy password gốc
            String rawPassword = request.getParameter("password");
            
            if (rawPassword == null || rawPassword.trim().isEmpty()) {
                response.sendRedirect("users?action=add&error=empty_password");
                return;
            }

            // Mã hóa BCrypt
            String hashedPassword = BCrypt.hashpw(rawPassword.trim(), BCrypt.gensalt(12));

            String roleStr = request.getParameter("role");
            String fullname = request.getParameter("fullname");
            String email = request.getParameter("email");
            String mobile = request.getParameter("mobile");
            String birthdayStr = request.getParameter("birthday");
            String genderStr = request.getParameter("gender");

            // Validate cơ bản
            if (fullname == null || fullname.trim().isEmpty()) {
                response.sendRedirect("users?action=add&error=empty_name");
                return;
            }

            if (email == null || email.trim().isEmpty()) {
                response.sendRedirect("users?action=add&error=empty_email");
                return;
            }

            // Tránh trùng ID
            if (userDAO.getUserById(id) != null) {
                id = generateNextUserId();
            }

            // Tạo user mới
            User user = new User();
            user.setId(id);
            user.setPassword(hashedPassword);  // <-- lưu mật khẩu đã mã hóa
            user.setFullname(fullname.trim());
            user.setEmail(email.trim());
            user.setRole("admin".equals(roleStr));

            if (mobile != null && !mobile.trim().isEmpty()) {
                user.setMobile(mobile.trim());
            }

            if (birthdayStr != null && !birthdayStr.trim().isEmpty()) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date birthday = sdf.parse(birthdayStr);
                    user.setBirthday(birthday);
                } catch (Exception ignore) {}
            }

            if (genderStr != null && !genderStr.trim().isEmpty()) {
                user.setGender("1".equals(genderStr));
            }

            boolean success = userDAO.insert(user);

            if (success) {
                response.sendRedirect("users?success=created&id=" + id);
            } else {
                response.sendRedirect("users?action=add&error=failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("users?action=add&error=exception");
        }
    }
    
    // ========================================
    // EDIT USER
    // ========================================
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("users?error=invalid_id");
                return;
            }
            
            User user = userDAO.getUserById(id);
            
            if (user == null) {
                response.sendRedirect("users?error=not_found");
                return;
            }
            
            request.setAttribute("editUser", user);
            request.setAttribute("view", "/admin/user-edit.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("users?error=invalid");
        }
    }
    
    private void updateUser(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {

        try {
            // Lấy ID
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("users?error=invalid_id");
                return;
            }
            
            // Lấy user hiện tại
            User user = userDAO.getUserById(id);
            
            if (user == null) {
                response.sendRedirect("users?error=not_found");
                return;
            }
            
            // Xử lý mật khẩu mới (nếu người dùng nhập)
            String rawPassword = request.getParameter("password");

            if (rawPassword != null && !rawPassword.trim().isEmpty()) {
                // Hash bằng BCrypt
                String hashedPassword = BCrypt.hashpw(rawPassword.trim(), BCrypt.gensalt(12));
                user.setPassword(hashedPassword);
            }
            
            // Cập nhật role
            String roleStr = request.getParameter("role");
            user.setRole("admin".equals(roleStr));
            
            // Cập nhật fullname
            String fullname = request.getParameter("fullname");
            if (fullname == null || fullname.trim().isEmpty()) {
                response.sendRedirect("users?action=edit&id=" + id + "&error=empty_name");
                return;
            }
            user.setFullname(fullname.trim());

            // Email
            String email = request.getParameter("email");
            if (email != null && !email.trim().isEmpty()) {
                user.setEmail(email.trim());
            }

            // Mobile
            String mobile = request.getParameter("mobile");
            if (mobile != null && !mobile.trim().isEmpty()) {
                user.setMobile(mobile.trim());
            }

            // Birthday
            String birthdayStr = request.getParameter("birthday");
            if (birthdayStr != null && !birthdayStr.trim().isEmpty()) {
                try {
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
                    Date birthday = sdf.parse(birthdayStr);
                    user.setBirthday(birthday);
                } catch (Exception ignore) {}
            }

            // Gender
            String genderStr = request.getParameter("gender");
            if (genderStr != null && !genderStr.trim().isEmpty()) {
                user.setGender("1".equals(genderStr));
            }

            // Update vào DB
            boolean success = userDAO.update(user);

            if (success) {
                response.sendRedirect("users?success=updated");
            } else {
                response.sendRedirect("users?action=edit&id=" + id + "&error=failed");
            }

        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("users?error=exception");
        }
    }
    
    // ========================================
    // DELETE USER
    // ========================================
    
    private void deleteUser(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("users?error=invalid_id");
                return;
            }
            
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            
            if (currentUser.getId().equals(id)) {
                response.sendRedirect("users?error=cannot_delete_self");
                return;
            }
            
            User user = userDAO.getUserById(id);
            
            if (user == null) {
                response.sendRedirect("users?error=not_found");
                return;
            }
            
            boolean success = userDAO.delete(id);
            
            if (success) {
                response.sendRedirect("users?success=deleted");
            } else {
                response.sendRedirect("users?error=cannotdelete");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("users?error=exception");
        }
    }
    
    // ========================================
    // TOGGLE ROLE
    // ========================================
    
    private void toggleUserRole(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("users?error=invalid_id");
                return;
            }
            
            HttpSession session = request.getSession();
            User currentUser = (User) session.getAttribute("user");
            
            if (currentUser.getId().equals(id)) {
                response.sendRedirect("users?error=cannot_change_own_role");
                return;
            }
            
            User user = userDAO.getUserById(id);
            
            if (user == null) {
                response.sendRedirect("users?error=not_found");
                return;
            }
            
            user.setRole(!user.isRole());
            
            boolean success = userDAO.update(user);
            
            if (success) {
                response.sendRedirect("users?success=role_updated");
            } else {
                response.sendRedirect("users?error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("users?error=exception");
        }
    }
    
    // ========================================
    // ERROR HANDLING
    // ========================================
    
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        
        e.printStackTrace();
        
        request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
        request.setAttribute("view", "/admin/error.jsp");
        
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
}