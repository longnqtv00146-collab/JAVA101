package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.util.List;
import java.util.UUID;

import DAO.CategoryDAO;
import DAO.NewsDAO;
import DAO.NewsletterDAO;
import Model.Category;
import Model.News;
import Model.User;

@WebServlet("/reporter/news")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,  // 2MB
    maxFileSize = 1024 * 1024 * 10,       // 10MB
    maxRequestSize = 1024 * 1024 * 50     // 50MB
)
public class ReporterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String UPLOAD_DIR = "uploads/images";
    
    private NewsDAO newsDAO;
    private CategoryDAO categoryDAO;
    private NewsletterDAO newsletterDAO;
    
    @Override
    public void init() throws ServletException {
        newsDAO = new NewsDAO();
        categoryDAO = new CategoryDAO();
        newsletterDAO = new NewsletterDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra đăng nhập và phân quyền
        User user = checkAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                listMyNews(request, response, user);
            } else {
                switch (action) {
                    case "add":
                        showAddForm(request, response, user);
                        break;
                    case "edit":
                        showEditForm(request, response, user);
                        break;
                    case "delete":
                        deleteNews(request, response, user);
                        break;
                    case "view":
                        viewNewsDetail(request, response, user);
                        break;
                    case "list":
                        listMyNews(request, response, user);
                        break;
                    default:
                        listMyNews(request, response, user);
                        break;
                }
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        User user = checkAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                doGet(request, response);
                return;
            }
            
            switch (action) {
                case "create":
                    createNews(request, response, user);
                    break;
                case "update":
                    updateNews(request, response, user);
                    break;
                default:
                    doGet(request, response);
                    break;
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }
    
    // ========================================
    // AUTHENTICATION & AUTHORIZATION
    // ========================================
    
    /**
     * Kiểm tra authentication và authorization
     */
    private User checkAuthentication(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User user = (User) session.getAttribute("user");
        
        // Kiểm tra phải là phóng viên (Role = false)
        if (user.isRole()) {  // isRole() = true => Admin
            response.sendRedirect(request.getContextPath() + "/admin/dashboard");
            return null;
        }
        
        return user;
    }
    
    // ========================================
    // LIST MY NEWS
    // ========================================
    
    /**
     * Danh sách tin CỦA TÔI
     */
    private void listMyNews(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            // Lấy tin của phóng viên này
            List<News> myNewsList = newsDAO.getNewsByAuthorId(user.getId());
            
            // Đếm số tin
            int totalNews = newsDAO.countNewsByAuthor(user.getId());
            
            // ✅ SET CURRENT PAGE cho menu active
            request.setAttribute("currentPage", "news-list");
            request.setAttribute("myNewsList", myNewsList);
            request.setAttribute("totalNews", totalNews);
            request.setAttribute("view", "/reporter/my-news.jsp");
            
            request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Lỗi khi tải danh sách tin");
        }
    }
    
    // ========================================
    // ADD NEWS
    // ========================================
    
    /**
     * Form thêm tin mới
     */
    private void showAddForm(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            List<Category> categories = categoryDAO.getAllCategories();
            
            // ✅ SET CURRENT PAGE cho menu active
            request.setAttribute("currentPage", "news-add");
            request.setAttribute("categories", categories);
            request.setAttribute("view", "/reporter/news-add.jsp");
            
            request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Lỗi khi tải form thêm tin");
        }
    }
    
    /**
     * Tạo tin mới
     */
    private void createNews(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            // Validate input
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            String categoryId = request.getParameter("categoryId");
            
            if (title == null || title.trim().isEmpty()) {
                response.sendRedirect("news?action=add&error=empty_title");
                return;
            }
            
            if (content == null || content.trim().isEmpty()) {
                response.sendRedirect("news?action=add&error=empty_content");
                return;
            }
            
            if (categoryId == null || categoryId.trim().isEmpty()) {
                response.sendRedirect("news?action=add&error=empty_category");
                return;
            }
            
            // Xử lý upload ảnh
            String imagePath = handleImageUpload(request);
            
            // Tạo đối tượng News
            News news = new News();
            news.setId("N" + System.currentTimeMillis());
            news.setTitle(title.trim());
            news.setContent(content.trim());
            news.setImage(imagePath);
            news.setAuthor(user.getFullname());
            news.setAuthorId(user.getId());
            news.setCategoryId(categoryId);
            news.setHome("on".equals(request.getParameter("home")));
            news.setPostedDate(new Date(System.currentTimeMillis()));
            
            // Lưu vào database
            boolean success = newsDAO.addNews(news);
            
            if (success) {
                // Gửi email newsletter cho subscribers
                sendNewsletterEmail(news);
                
                response.sendRedirect("news?success=created");
            } else {
                response.sendRedirect("news?action=add&error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?action=add&error=exception");
        }
    }
    
    // ========================================
    // EDIT NEWS
    // ========================================
    
    /**
     * Form sửa tin
     */
    private void showEditForm(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            // Kiểm tra tin có tồn tại không
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            // Kiểm tra tin có phải của mình không
            if (!news.getAuthorId().equals(user.getId())) {
                response.sendRedirect("news?error=unauthorized");
                return;
            }
            
            List<Category> categories = categoryDAO.getAllCategories();
            
            // ✅ SET CURRENT PAGE cho menu active
            request.setAttribute("currentPage", "news-edit");
            request.setAttribute("news", news);
            request.setAttribute("categories", categories);
            request.setAttribute("view", "/reporter/news-edit.jsp");
            
            request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=invalid");
        }
    }
    
    /**
     * Cập nhật tin
     */
    private void updateNews(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            // Kiểm tra tin có tồn tại không
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            // Kiểm tra quyền sở hữu
            if (!news.getAuthorId().equals(user.getId())) {
                response.sendRedirect("news?error=unauthorized");
                return;
            }
            
            // Validate input
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            String categoryId = request.getParameter("categoryId");
            
            if (title == null || title.trim().isEmpty()) {
                response.sendRedirect("news?action=edit&id=" + id + "&error=empty_title");
                return;
            }
            
            if (content == null || content.trim().isEmpty()) {
                response.sendRedirect("news?action=edit&id=" + id + "&error=empty_content");
                return;
            }
            
            // Xử lý upload ảnh mới (nếu có)
            String imagePath = handleImageUpload(request);
            
            // Cập nhật thông tin
            news.setTitle(title.trim());
            news.setContent(content.trim());
            
            // Chỉ cập nhật ảnh nếu có upload ảnh mới
            if (imagePath != null && !imagePath.isEmpty()) {
                news.setImage(imagePath);
            }
            
            news.setCategoryId(categoryId);
            news.setHome("on".equals(request.getParameter("home")));
            
            boolean success = newsDAO.updateNews(news);
            
            if (success) {
                response.sendRedirect("news?success=updated");
            } else {
                response.sendRedirect("news?action=edit&id=" + id + "&error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=exception");
        }
    }
    
    // ========================================
    // DELETE NEWS
    // ========================================
    
    /**
     * Xóa tin
     */
    private void deleteNews(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            // Kiểm tra tin có tồn tại không
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            // Kiểm tra quyền sở hữu
            if (!news.getAuthorId().equals(user.getId())) {
                response.sendRedirect("news?error=unauthorized");
                return;
            }
            
            // Xóa ảnh khỏi server (nếu có)
            deleteImageFile(news.getImage());
            
            // Xóa tin khỏi database
            boolean success = newsDAO.deleteNews(id);
            
            if (success) {
                response.sendRedirect("news?success=deleted");
            } else {
                response.sendRedirect("news?error=cannotdelete");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=exception");
        }
    }
    
    // ========================================
    // VIEW NEWS DETAIL
    // ========================================
    
    /**
     * Xem chi tiết tin
     */
    private void viewNewsDetail(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            // Kiểm tra tin có tồn tại không
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            // Kiểm tra quyền xem (chỉ xem tin của mình)
            if (!news.getAuthorId().equals(user.getId())) {
                response.sendRedirect("news?error=unauthorized");
                return;
            }
            
            // Lấy thông tin category
            Category category = categoryDAO.getById(news.getCategoryId());
            
            // ✅ SET CURRENT PAGE cho menu active
            request.setAttribute("currentPage", "news-view");
            request.setAttribute("news", news);
            request.setAttribute("category", category);
            request.setAttribute("view", "/reporter/news-detail.jsp");
            
            request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=invalid");
        }
    }
    
    // ========================================
    // IMAGE UPLOAD
    // ========================================
    
    /**
     * Xử lý upload ảnh
     */
    private String handleImageUpload(HttpServletRequest request) throws Exception {
        Part filePart = request.getPart("imageFile");
        
        // Nếu không có file upload, kiểm tra URL
        if (filePart == null || filePart.getSize() == 0) {
            String imageUrl = request.getParameter("image");
            return (imageUrl != null && !imageUrl.trim().isEmpty()) ? imageUrl.trim() : null;
        }
        
        // Validate file
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String fileExtension = getFileExtension(fileName);
        
        // Kiểm tra định dạng file
        if (!isValidImageExtension(fileExtension)) {
            throw new Exception("Invalid image format. Only JPG, JPEG, PNG, GIF allowed.");
        }
        
        // Kiểm tra kích thước file (max 10MB)
        if (filePart.getSize() > 10 * 1024 * 1024) {
            throw new Exception("File size exceeds 10MB limit.");
        }
        
        // Tạo tên file unique
        String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
        
        // Đường dẫn upload
        String uploadPath = request.getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
        File uploadDir = new File(uploadPath);
        
        // Tạo thư mục nếu chưa có
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        
        // Lưu file
        String filePath = uploadPath + File.separator + uniqueFileName;
        try (InputStream input = filePart.getInputStream()) {
            Files.copy(input, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
        }
        
        // Trả về đường dẫn relative
        return UPLOAD_DIR + "/" + uniqueFileName;
    }
    
    /**
     * Xóa file ảnh
     */
    private void deleteImageFile(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            return;
        }
        
        // Chỉ xóa file local (không xóa URL)
        if (imagePath.startsWith("http://") || imagePath.startsWith("https://")) {
            return;
        }
        
        try {
            String fullPath = getServletContext().getRealPath("") + File.separator + imagePath;
            File file = new File(fullPath);
            
            if (file.exists()) {
                file.delete();
                System.out.println("🗑️ Đã xóa file: " + imagePath);
            }
        } catch (Exception e) {
            System.err.println("⚠️ Lỗi khi xóa file: " + e.getMessage());
        }
    }
    
    /**
     * Lấy extension của file
     */
    private String getFileExtension(String fileName) {
        int lastDot = fileName.lastIndexOf('.');
        return (lastDot > 0) ? fileName.substring(lastDot + 1).toLowerCase() : "";
    }
    
    /**
     * Kiểm tra extension hợp lệ
     */
    private boolean isValidImageExtension(String extension) {
        return extension.equals("jpg") || 
               extension.equals("jpeg") || 
               extension.equals("png") || 
               extension.equals("gif") ||
               extension.equals("webp");
    }
    
    // ========================================
    // NEWSLETTER EMAIL
    // ========================================
    
    /**
     * Gửi email newsletter cho subscribers
     */
    private void sendNewsletterEmail(News news) {
        try {
            List<String> subscribers = newsletterDAO.getActiveEmails();
            
            if (subscribers == null || subscribers.isEmpty()) {
                System.out.println("📧 Không có subscribers nào để gửi email");
                return;
            }
            
            // TODO: Implement email sending logic
            // Có thể dùng JavaMail API hoặc service như SendGrid, AWS SES
            
            System.out.println("📧 Gửi email đến " + subscribers.size() + " subscribers");
            System.out.println("📰 Tiêu đề: " + news.getTitle());
            System.out.println("✍️ Tác giả: " + news.getAuthor());
            
            // Example: Send email using JavaMail
            /*
            for (String email : subscribers) {
                EmailUtil.sendNewNewsNotification(email, news);
            }
            */
            
        } catch (Exception e) {
            System.err.println("⚠️ Lỗi gửi newsletter: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    // ========================================
    // ERROR HANDLING
    // ========================================
    
    /**
     * Xử lý lỗi chung
     */
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        
        e.printStackTrace();
        
        request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
        request.setAttribute("view", "/reporter/error.jsp");
        
        request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
    }
}