package Serverlet;

import java.io.IOException;

import DAO.UserDAO;
import Model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.Cookie;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    private UserDAO dao = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String email = req.getParameter("email");
        String password = req.getParameter("password");
        String remember = req.getParameter("remember");

        try {
            // 1. Lấy thông tin user theo email
            User user = dao.login(email);

            if (user == null) {
                resp.sendRedirect("login.jsp?error=notfound");
                return;
            }

            // 2. Kiểm tra password BCrypt
            boolean match = BCrypt.checkpw(password, user.getPassword());
            if (!match) {
                resp.sendRedirect("login.jsp?error=wrongpass");
                return;
            }

            // 3. Thành công -> lưu session
            req.getSession().setAttribute("user", user);

            // 4. Remember-me
            if ("on".equals(remember)) {
                Cookie ck = new Cookie("remember_email", email);
                ck.setMaxAge(7 * 24 * 60 * 60); // 7 ngày
                ck.setPath("/");
                resp.addCookie(ck);
            }

            // 5. Chuyển trang chính
            resp.sendRedirect("home");

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("login.jsp?error=system");
        }
    }
}
