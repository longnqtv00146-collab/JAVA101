package Serverlet;

import java.io.IOException;
import java.util.List;

import DAO.CategoryDAO;
import DAO.NewsDAO;
import Model.Category;
import Model.News;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/list")
public class ListServlet extends HttpServlet {

    private CategoryDAO categoryDao = new CategoryDAO();
    private NewsDAO newsDao = new NewsDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        // Lấy mã danh mục từ URL
        String cateId = req.getParameter("cate");

        if (cateId == null || cateId.isEmpty()) {
            resp.sendRedirect("home");
            return;
        }

        // Lấy tất cả danh mục cho menu
        List<Category> categories = categoryDao.findAll();
        req.setAttribute("categories", categories);

        // Lấy danh sách tin theo loại
        List<News> newsList = newsDao.getByCategory(cateId);
        req.setAttribute("newsList", newsList);

        // Lấy tên danh mục
        String cateName = "";
        for (Category c : categories) {
            if (c.getId().equalsIgnoreCase(cateId)) {
                cateName = c.getName();
                break;
            }
        }
        req.setAttribute("currentCategoryName", cateName);

        // Gửi tới layout
        req.setAttribute("view", "/views/list.jsp");
        req.getRequestDispatcher("/layout.jsp").forward(req, resp);
    }
}