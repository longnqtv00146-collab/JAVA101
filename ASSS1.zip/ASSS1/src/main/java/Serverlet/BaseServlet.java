package Serverlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import DAO.CategoryDAO;
import DAO.NewsDAO;
import Model.Category;
import Model.News;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

public abstract class BaseServlet extends HttpServlet {

    protected NewsDAO newsDao = new NewsDAO();
    protected CategoryDAO categoryDao = new CategoryDAO();

    protected void loadCommonData(HttpServletRequest req) {
        // 1) MENU (CATEGORIES)
        List<Category> categories = categoryDao.findAll();
        req.setAttribute("categories", categories);

        // 2) TOP 5 TIN HOT
        req.setAttribute("topHot", newsDao.getTopHot(5));

        // 3) TOP 5 TIN MỚI NHẤT
        req.setAttribute("latestNews", newsDao.getLatest(5));

        // 4) LỊCH SỬ XEM (từ session)
        HttpSession session = req.getSession();
        @SuppressWarnings("unchecked")
        List<News> history = (List<News>) session.getAttribute("historyNews");
        
        if (history == null) {
            history = new ArrayList<>();
            session.setAttribute("historyNews", history); // ← QUAN TRỌNG!
        }
        
        req.setAttribute("historyNews", history);
    }

    protected void forwardToLayout(HttpServletRequest req, HttpServletResponse resp, String viewPath) 
            throws ServletException, IOException {
        req.setAttribute("view", viewPath);
        req.getRequestDispatcher("/layout.jsp").forward(req, resp);
    }
}