package Serverlet;

import java.io.IOException;

import DAO.NewsletterDAO;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/newsletter")
public class NewsletterServlet extends HttpServlet {

    private NewsletterDAO dao = new NewsletterDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        String email = req.getParameter("email");

        if (email == null || email.isBlank()) {
            resp.sendRedirect("layout.jsp?newsmsg=empty");
            return;
        }

        try {
            if (dao.exists(email)) {
                resp.sendRedirect("layout.jsp?newsmsg=exists");
            } else {
                dao.insert(email);
                resp.sendRedirect("layout.jsp?newsmsg=success");
            }

        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect("layout.jsp?newsmsg=error");
        }
    }
}
