package Serverlet;

import java.io.IOException;
import java.util.List;

import DAO.NewsDAO;
import DAO.CategoryDAO;
import Model.News;
import Model.Category;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/detail")
public class DetailServlet extends HttpServlet {

    private NewsDAO newsDao = new NewsDAO();
    private CategoryDAO cateDao = new CategoryDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        // Lấy id tin từ URL
        // VD: /detail?id=N001
        String id = req.getParameter("id");

        if (id == null || id.isEmpty()) {
            resp.sendRedirect("home");
            return;
        }

        // Lấy tin theo ID
        News n = newsDao.getById(id);
        if (n == null) {
            resp.sendRedirect("home");
            return;
        }

        // Gửi tin sang view
        req.setAttribute("news", n);

        // Lấy 5 tin cùng loại
        List<News> related = newsDao.getByCategory(n.getCategoryId());
        req.setAttribute("related", related);

        // Load category lên menu
        List<Category> categories = cateDao.findAll();
        req.setAttribute("categories", categories);

        // Gửi sang layout.jsp
        req.setAttribute("view", "/views/detail.jsp");
        req.getRequestDispatcher("/layout.jsp").forward(req, resp);
    }
}
