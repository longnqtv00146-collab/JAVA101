package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import DAO.NewsDAO;
import Model.News;
import Model.User;

@WebServlet("/reporter/profile")
public class ReporterProfileServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private NewsDAO newsDAO;
    
    @Override
    public void init() throws ServletException {
        newsDAO = new NewsDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Set cache control
        response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate");
        response.setHeader("Pragma", "no-cache");
        response.setDateHeader("Expires", 0);
        
        // Kiểm tra authentication
        User user = checkAuthentication(request, response);
        if (user == null) return;
        
        try {
            // Lấy thống kê của phóng viên
            int totalNews = newsDAO.countNewsByAuthor(user.getId());
            int totalViews = newsDAO.getTotalViewsByAuthor(user.getId());
            int homeNews = newsDAO.countHomeNewsByAuthor(user.getId());
            
            // Tính số ngày hoạt động (giả sử từ ngày đăng tin đầu tiên)
            Date firstNewsDate = newsDAO.getFirstNewsDateByAuthor(user.getId());
            int daysActive = 0;
            if (firstNewsDate != null) {
                long diff = new Date().getTime() - firstNewsDate.getTime();
                daysActive = (int) (diff / (1000 * 60 * 60 * 24));
            }
            
            // Lấy tin mới nhất
            List<News> recentNews = newsDAO.getRecentNewsByAuthor(user.getId(), 5);
            
            // Set attributes
            request.setAttribute("totalNews", totalNews);
            request.setAttribute("totalViews", totalViews);
            request.setAttribute("homeNews", homeNews);
            request.setAttribute("daysActive", daysActive);
            request.setAttribute("recentNews", recentNews);
            
            request.setAttribute("currentPage", "profile");
            request.setAttribute("view", "/reporter/profile.jsp");
            request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Lỗi khi tải hồ sơ");
        }
    }
    
    /**
     * Kiểm tra authentication và authorization
     */
    private User checkAuthentication(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User user = (User) session.getAttribute("user");
        
        // Kiểm tra phải là phóng viên (Role = false)
        if (user.isRole()) {  // isRole() = true => Admin
            response.sendRedirect(request.getContextPath() + "/admin/dashboard");
            return null;
        }
        
        return user;
    }
}