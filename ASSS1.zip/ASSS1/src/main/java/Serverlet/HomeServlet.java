package Serverlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import Model.Category;
import Model.News;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet("/home")
public class HomeServlet extends BaseServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setCharacterEncoding("UTF-8");

        // ============================================
        // LOAD DỮ LIỆU CHUNG (menu, sidebar)
        // ============================================
        loadCommonData(req);

        // ============================================
        // XỬ LÝ VIEW DỰA THEO THAM SỐ
        // ============================================
        String view = req.getParameter("view");
        String page = "/views/home.jsp"; // Mặc định

        if (view == null || view.equals("home")) {
            // ---------------------- TRANG CHỦ ----------------------
            req.setAttribute("homeNews", newsDao.getHomeNews());
            page = "/views/home.jsp";

        } else if (view.equals("list")) {
            // ---------------------- DANH SÁCH TIN THEO DANH MỤC ----------------------
            String categoryId = req.getParameter("cate");
            
            req.setAttribute("newsList", newsDao.getByCategory(categoryId));
            req.setAttribute("currentCategoryId", categoryId);
            
            // Tìm tên danh mục để hiển thị
            @SuppressWarnings("unchecked")
            List<Category> categories = (List<Category>) req.getAttribute("categories");
            String categoryName = "Tất cả tin tức";
            
            if (categories != null) {  // ← Kiểm tra null
                for (Category cat : categories) {
                    if (cat.getId().equals(categoryId)) {
                        categoryName = cat.getName();
                        break;
                    }
                }
            }
            req.setAttribute("currentCategoryName", categoryName);

            page = "/views/list.jsp";

        } else if (view.equals("detail")) {
            // ---------------------- CHI TIẾT TIN ----------------------
            String newsId = req.getParameter("id");
            News news = newsDao.getById(newsId);

            if (news != null) {
                // Tăng lượt xem
                newsDao.increaseViews(newsId);
                news.setViewCount(news.getViewCount() + 1);

                req.setAttribute("news", news);

                // Tin liên quan
                List<News> relatedNews = newsDao.getRelated(news.getCategoryId(), newsId, 5);
                req.setAttribute("relatedNews", relatedNews);

                // ============================================
                // CẬP NHẬT LỊCH SỬ XEM - FIX NULL POINTER
                // ============================================
                HttpSession session = req.getSession();
                @SuppressWarnings("unchecked")
                List<News> history = (List<News>) session.getAttribute("historyNews");
                
                // ← KIỂM TRA NULL TRƯỚC KHI DÙNG
                if (history == null) {
                    history = new ArrayList<>();
                }
                
                history.removeIf(n -> n.getId().equals(newsId)); // Xóa nếu đã có
                history.add(0, news); // Thêm lên đầu

                if (history.size() > 5) {
                    history = history.subList(0, 5); // Giới hạn 5 tin
                }

                session.setAttribute("historyNews", history);
                
                // Cập nhật lại attribute cho sidebar
                req.setAttribute("historyNews", history);
            }

            page = "/views/detail.jsp";
        }

        // ============================================
        // FORWARD ĐẾN LAYOUT
        // ============================================
        forwardToLayout(req, resp, page);
    }
}