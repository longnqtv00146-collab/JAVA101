package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.MultipartConfig;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import jakarta.servlet.http.Part;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.sql.Date;
import java.util.List;
import java.util.UUID;

import DAO.CategoryDAO;
import DAO.NewsDAO;
import Model.Category;
import Model.News;
import Model.User;

/**
 * Admin quản lý TẤT CẢ tin tức trong hệ thống
 */
@WebServlet("/admin/news")
@MultipartConfig(
    fileSizeThreshold = 1024 * 1024 * 2,
    maxFileSize = 1024 * 1024 * 10,
    maxRequestSize = 1024 * 1024 * 50
)
public class AdminNewsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    private static final String UPLOAD_DIR = "uploads/images";
    
    private NewsDAO newsDAO;
    private CategoryDAO categoryDAO;
    
    @Override
    public void init() throws ServletException {
        newsDAO = new NewsDAO();
        categoryDAO = new CategoryDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        User user = checkAdminAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        if (action == null || action.isEmpty()) {
            action = "list";  // xử lý mặc định
        }
        
        try {
            if (action == null || action.isEmpty()) {
                listAllNews(request, response);
            } else {
                switch (action) {
                    case "add":
                        showAddForm(request, response);
                        break;
                    case "edit":
                        showEditForm(request, response);
                        break;
                    case "delete":
                        deleteNews(request, response);
                        break;
                    case "view":
                        viewNewsDetail(request, response);
                        break;
                    case "list":
                        listAllNews(request, response);
                        break;
                    default:
                        listAllNews(request, response);
                        break;
                }
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        response.setCharacterEncoding("UTF-8");
        
        User user = checkAdminAuthentication(request, response);
        if (user == null) return;
        
        String action = request.getParameter("action");
        
        try {
            if (action == null || action.isEmpty()) {
                doGet(request, response);
                return;
            }
            
            switch (action) {
                case "create":
                    createNews(request, response, user);
                    break;
                case "update":
                    updateNews(request, response);
                    break;
                default:
                    doGet(request, response);
                    break;
            }
        } catch (Exception e) {
            handleError(request, response, e);
        }
    }
    
    // ========================================
    // AUTHENTICATION
    // ========================================
    
    private User checkAdminAuthentication(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User user = (User) session.getAttribute("user");
        
        if (!user.isRole()) {
            response.sendRedirect(request.getContextPath() + "/home");
            return null;
        }
        
        return user;
    }
    
    // ========================================
    // LIST ALL NEWS
    // ========================================
    
    private void listAllNews(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String categoryFilter = request.getParameter("category");
            List<News> newsList;
            
            if (categoryFilter != null && !categoryFilter.isEmpty()) {
                newsList = newsDAO.getByCategory(categoryFilter);
            } else {
                newsList = newsDAO.getAllNews();
            }
            
            int totalNews = newsDAO.getTotalNews();
            List<Category> categories = categoryDAO.getAllCategories();
            
            request.setAttribute("newsList", newsList);
            request.setAttribute("totalNews", totalNews);
            request.setAttribute("categories", categories);
            request.setAttribute("selectedCategory", categoryFilter);
            request.setAttribute("view", "/admin/news-list.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
    
    // ========================================
    // ADD NEWS
    // ========================================
    
    private void showAddForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<Category> categories = categoryDAO.getAllCategories();
            
            request.setAttribute("categories", categories);
            request.setAttribute("view", "/admin/news-add.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
    
    private void createNews(HttpServletRequest request, HttpServletResponse response, User user) 
            throws ServletException, IOException {
        
        try {
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            String categoryId = request.getParameter("categoryId");
            
            if (title == null || title.trim().isEmpty()) {
                response.sendRedirect("news?action=add&error=empty_title");
                return;
            }
            
            if (content == null || content.trim().isEmpty()) {
                response.sendRedirect("news?action=add&error=empty_content");
                return;
            }
            
            if (categoryId == null || categoryId.trim().isEmpty()) {
                response.sendRedirect("news?action=add&error=empty_category");
                return;
            }
            
            String imagePath = handleImageUpload(request);
            
            News news = new News();
            news.setId("N" + System.currentTimeMillis());
            news.setTitle(title.trim());
            news.setContent(content.trim());
            news.setImage(imagePath);
            news.setAuthor(user.getFullname());
            news.setAuthorId(user.getId());
            news.setCategoryId(categoryId);
            news.setHome("on".equals(request.getParameter("home")));
            news.setPostedDate(new Date(System.currentTimeMillis()));
            
            boolean success = newsDAO.addNews(news);
            
            if (success) {
                response.sendRedirect("news?success=created");
            } else {
                response.sendRedirect("news?action=add&error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?action=add&error=exception");
        }
    }
    
    // ========================================
    // EDIT NEWS
    // ========================================
    
    private void showEditForm(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            List<Category> categories = categoryDAO.getAllCategories();
            
            request.setAttribute("news", news);
            request.setAttribute("categories", categories);
            request.setAttribute("view", "/admin/news-edit.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=invalid");
        }
    }
    
    private void updateNews(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            String title = request.getParameter("title");
            String content = request.getParameter("content");
            String categoryId = request.getParameter("categoryId");
            
            if (title == null || title.trim().isEmpty()) {
                response.sendRedirect("news?action=edit&id=" + id + "&error=empty_title");
                return;
            }
            
            if (content == null || content.trim().isEmpty()) {
                response.sendRedirect("news?action=edit&id=" + id + "&error=empty_content");
                return;
            }
            
            String imagePath = handleImageUpload(request);
            
            news.setTitle(title.trim());
            news.setContent(content.trim());
            
            if (imagePath != null && !imagePath.isEmpty()) {
                news.setImage(imagePath);
            }
            
            news.setCategoryId(categoryId);
            news.setHome("on".equals(request.getParameter("home")));
            
            boolean success = newsDAO.updateNews(news);
            
            if (success) {
                response.sendRedirect("news?success=updated");
            } else {
                response.sendRedirect("news?action=edit&id=" + id + "&error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=exception");
        }
    }
    
    // ========================================
    // DELETE NEWS
    // ========================================
    
    private void deleteNews(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            deleteImageFile(news.getImage());
            
            boolean success = newsDAO.deleteNews(id);
            
            if (success) {
                response.sendRedirect("news?success=deleted");
            } else {
                response.sendRedirect("news?error=cannotdelete");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=exception");
        }
    }
    
    // ========================================
    // VIEW DETAIL
    // ========================================
    
    private void viewNewsDetail(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String id = request.getParameter("id");
            
            if (id == null || id.trim().isEmpty()) {
                response.sendRedirect("news?error=invalid_id");
                return;
            }
            
            News news = newsDAO.getNewsById(id);
            
            if (news == null) {
                response.sendRedirect("news?error=not_found");
                return;
            }
            
            Category category = categoryDAO.getById(news.getCategoryId());
            
            request.setAttribute("news", news);
            request.setAttribute("category", category);
            request.setAttribute("view", "/admin/news-detail.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("news?error=invalid");
        }
    }
    
    // ========================================
    // IMAGE UPLOAD
    // ========================================
    
    private String handleImageUpload(HttpServletRequest request) throws Exception {
        Part filePart = request.getPart("imageFile");
        
        if (filePart == null || filePart.getSize() == 0) {
            String imageUrl = request.getParameter("image");
            return (imageUrl != null && !imageUrl.trim().isEmpty()) ? imageUrl.trim() : null;
        }
        
        String fileName = Paths.get(filePart.getSubmittedFileName()).getFileName().toString();
        String fileExtension = getFileExtension(fileName);
        
        if (!isValidImageExtension(fileExtension)) {
            throw new Exception("Invalid image format");
        }
        
        if (filePart.getSize() > 10 * 1024 * 1024) {
            throw new Exception("File too large");
        }
        
        String uniqueFileName = UUID.randomUUID().toString() + "_" + fileName;
        String uploadPath = request.getServletContext().getRealPath("") + File.separator + UPLOAD_DIR;
        File uploadDir = new File(uploadPath);
        
        if (!uploadDir.exists()) {
            uploadDir.mkdirs();
        }
        
        String filePath = uploadPath + File.separator + uniqueFileName;
        try (InputStream input = filePart.getInputStream()) {
            Files.copy(input, Paths.get(filePath), StandardCopyOption.REPLACE_EXISTING);
        }
        
        return UPLOAD_DIR + "/" + uniqueFileName;
    }
    
    private void deleteImageFile(String imagePath) {
        if (imagePath == null || imagePath.trim().isEmpty()) {
            return;
        }
        
        if (imagePath.startsWith("http://") || imagePath.startsWith("https://")) {
            return;
        }
        
        try {
            String fullPath = getServletContext().getRealPath("") + File.separator + imagePath;
            File file = new File(fullPath);
            
            if (file.exists()) {
                file.delete();
            }
        } catch (Exception e) {
            System.err.println("Error deleting file: " + e.getMessage());
        }
    }
    
    private String getFileExtension(String fileName) {
        int lastDot = fileName.lastIndexOf('.');
        return (lastDot > 0) ? fileName.substring(lastDot + 1).toLowerCase() : "";
    }
    
    private boolean isValidImageExtension(String extension) {
        return extension.equals("jpg") || 
               extension.equals("jpeg") || 
               extension.equals("png") || 
               extension.equals("gif") ||
               extension.equals("webp");
    }
    
    // ========================================
    // ERROR HANDLING
    // ========================================
    
    private void handleError(HttpServletRequest request, HttpServletResponse response, Exception e) 
            throws ServletException, IOException {
        
        e.printStackTrace();
        
        request.setAttribute("errorMessage", "Đã xảy ra lỗi: " + e.getMessage());
        request.setAttribute("view", "/admin/error.jsp");
        
        request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
    }
}