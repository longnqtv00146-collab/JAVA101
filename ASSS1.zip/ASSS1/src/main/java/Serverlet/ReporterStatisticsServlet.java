package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import DAO.NewsDAO;
import Model.News;
import Model.User;

@WebServlet("/reporter/statistics")
public class ReporterStatisticsServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private NewsDAO newsDAO;
    
    @Override
    public void init() throws ServletException {
        newsDAO = new NewsDAO();
    }

    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        // Kiểm tra authentication
        User user = checkAuthentication(request, response);
        if (user == null) return;
        
        try {
            // Lấy tất cả tin của user
            List<News> allNews = newsDAO.getNewsByAuthorId(user.getId());
            
            // 1. Tổng số tin
            int totalNews = allNews.size();
            
            // 2. Tin tháng này
            int newsThisMonth = countNewsThisMonth(allNews);
            
            // 3. Tổng lượt xem (giả sử mỗi tin có trường views)
            int totalViews = calculateTotalViews(allNews);
            
            // 4. Tin trang chủ (home = true)
            int homeNews = countHomeNews(allNews);
            
            // 5. Thống kê theo từng tháng (12 tháng)
            int[] monthlyStats = getMonthlyStats(allNews);
            
            // 6. Tính tăng trưởng
            int growthRate = calculateGrowthRate(monthlyStats);
            
            // 7. Trung bình mỗi tháng
            int avgPerMonth = totalNews > 0 ? totalNews / 12 : 0;
            
            // 8. Tháng cao nhất
            int maxMonth = getMaxMonth(monthlyStats);
            
            // 9. Thống kê theo danh mục
            List<CategoryStat> categoryStats = getCategoryStats(allNews);
            
            // Set attributes
            request.setAttribute("currentPage", "statistics");
            request.setAttribute("totalNews", totalNews);
            request.setAttribute("newsThisMonth", newsThisMonth);
            request.setAttribute("totalViews", totalViews);
            request.setAttribute("homeNews", homeNews);
            request.setAttribute("growthRate", growthRate);
            request.setAttribute("avgPerMonth", avgPerMonth);
            request.setAttribute("maxMonth", maxMonth);
            request.setAttribute("categoryStats", categoryStats);
            
            // Set dữ liệu từng tháng
            for (int i = 0; i < 12; i++) {
                request.setAttribute("month" + (i + 1), monthlyStats[i]);
            }
            
            request.setAttribute("view", "/reporter/statistics.jsp");
            request.getRequestDispatcher("/reporter/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 
                "Lỗi khi tải thống kê");
        }
    }
    
    /**
     * Kiểm tra authentication
     */
    private User checkAuthentication(HttpServletRequest request, HttpServletResponse response) 
            throws IOException {
        
        HttpSession session = request.getSession(false);
        if (session == null || session.getAttribute("user") == null) {
            response.sendRedirect(request.getContextPath() + "/login.jsp");
            return null;
        }
        
        User user = (User) session.getAttribute("user");
        
        if (user.isRole()) {
            response.sendRedirect(request.getContextPath() + "/admin/dashboard");
            return null;
        }
        
        return user;
    }
    
    /**
     * Đếm tin trong tháng hiện tại
     */
    private int countNewsThisMonth(List<News> allNews) {
        Calendar now = Calendar.getInstance();
        int currentMonth = now.get(Calendar.MONTH);
        int currentYear = now.get(Calendar.YEAR);
        
        int count = 0;
        for (News news : allNews) {
            if (news.getPostedDate() != null) {
                Calendar postCal = Calendar.getInstance();
                postCal.setTime(news.getPostedDate());
                
                if (postCal.get(Calendar.MONTH) == currentMonth && 
                    postCal.get(Calendar.YEAR) == currentYear) {
                    count++;
                }
            }
        }
        return count;
    }
    
    /**
     * Tính tổng lượt xem
     */
    private int calculateTotalViews(List<News> allNews) {
        // Nếu model News có trường views
        // int total = 0;
        // for (News news : allNews) {
        //     total += news.getViews();
        // }
        // return total;
        
        // Tạm thời trả về số giả định
        return allNews.size() * 80; // Giả sử mỗi tin ~80 views
    }
    
    /**
     * Đếm tin trang chủ
     */
    private int countHomeNews(List<News> allNews) {
        int count = 0;
        for (News news : allNews) {
            if (news.isHome()) {
                count++;
            }
        }
        return count;
    }
    
    /**
     * Thống kê theo 12 tháng
     */
    private int[] getMonthlyStats(List<News> allNews) {
        int[] stats = new int[12];
        Calendar now = Calendar.getInstance();
        int currentYear = now.get(Calendar.YEAR);
        
        for (News news : allNews) {
            if (news.getPostedDate() != null) {
                Calendar postCal = Calendar.getInstance();
                postCal.setTime(news.getPostedDate());
                
                // Chỉ tính năm hiện tại
                if (postCal.get(Calendar.YEAR) == currentYear) {
                    int month = postCal.get(Calendar.MONTH); // 0-11
                    stats[month]++;
                }
            }
        }
        
        return stats;
    }
    
    /**
     * Tính tỷ lệ tăng trưởng
     */
    private int calculateGrowthRate(int[] monthlyStats) {
        Calendar now = Calendar.getInstance();
        int currentMonth = now.get(Calendar.MONTH);
        
        if (currentMonth == 0) return 0; // Tháng 1 không có tháng trước
        
        int thisMonth = monthlyStats[currentMonth];
        int lastMonth = monthlyStats[currentMonth - 1];
        
        if (lastMonth == 0) return thisMonth > 0 ? 100 : 0;
        
        return (int) (((thisMonth - lastMonth) / (double) lastMonth) * 100);
    }
    
    /**
     * Tìm tháng có nhiều tin nhất
     */
    private int getMaxMonth(int[] monthlyStats) {
        int max = 0;
        for (int stat : monthlyStats) {
            if (stat > max) {
                max = stat;
            }
        }
        return max;
    }
    
    /**
     * Thống kê theo danh mục
     */
    private List<CategoryStat> getCategoryStats(List<News> allNews) {
        // Dùng Map để đếm
        java.util.Map<String, Integer> categoryMap = new java.util.HashMap<>();
        
        for (News news : allNews) {
            String categoryId = news.getCategoryId();
            if (categoryId != null) {
                categoryMap.put(categoryId, categoryMap.getOrDefault(categoryId, 0) + 1);
            }
        }
        
        // Chuyển sang List
        List<CategoryStat> result = new ArrayList<>();
        
        // Lấy tên category từ database (hoặc hard-code tạm)
        for (java.util.Map.Entry<String, Integer> entry : categoryMap.entrySet()) {
            CategoryStat stat = new CategoryStat();
            stat.setId(entry.getKey());
            stat.setName(getCategoryName(entry.getKey())); // Hàm lấy tên category
            stat.setCount(entry.getValue());
            result.add(stat);
        }
        
        return result;
    }
    
    /**
     * Lấy tên category từ ID (tạm thời hard-code)
     */
    private String getCategoryName(String categoryId) {
        // TODO: Query từ database
        switch (categoryId) {
            case "1": return "Thể thao";
            case "2": return "Công nghệ";
            case "3": return "Giải trí";
            case "4": return "Kinh tế";
            case "5": return "Chính trị";
            case "6": return "Đời sống";
            default: return "Khác";
        }
    }
    
    /**
     * Inner class để lưu thống kê category
     */
    public static class CategoryStat {
        private String id;
        private String name;
        private int count;
        
        public String getId() { return id; }
        public void setId(String id) { this.id = id; }
        
        public String getName() { return name; }
        public void setName(String name) { this.name = name; }
        
        public int getCount() { return count; }
        public void setCount(int count) { this.count = count; }
    }
}