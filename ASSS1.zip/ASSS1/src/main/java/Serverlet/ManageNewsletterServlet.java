package Serverlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

import DAO.NewsletterDAO;
import Model.Newsletter;

/**
 * Admin quản lý Newsletters
 * CRUD cho danh sách email đăng ký
 */
@WebServlet("/admin/newsletters")
public class ManageNewsletterServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;
    
    private NewsletterDAO newsletterDAO;
    
    @Override
    public void init() throws ServletException {
        newsletterDAO = new NewsletterDAO();
    }

    protected void doGet(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        String action = request.getParameter("action");
        
        if ("delete".equals(action)) {
            deleteNewsletter(request, response);
        } else if ("toggle".equals(action)) {
            toggleStatus(request, response);
        } else {
            listNewsletters(request, response);
        }
    }

    protected void doPost(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        request.setCharacterEncoding("UTF-8");
        String action = request.getParameter("action");
        
        if ("add".equals(action)) {
            addNewsletter(request, response);
        } else {
            doGet(request, response);
        }
    }
    
    /**
     * Danh sách tất cả newsletters
     */
    private void listNewsletters(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            List<Newsletter> newsletters = newsletterDAO.getAllNewsletters();
            int activeCount = newsletterDAO.getActiveSubscriberCount();
            
            request.setAttribute("newsletters", newsletters);
            request.setAttribute("activeCount", activeCount);
            request.setAttribute("view", "/admin/newsletter-list.jsp");
            
            request.getRequestDispatcher("/admin/layout.jsp").forward(request, response);
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
        }
    }
    
    /**
     * Thêm email mới (manual)
     */
    private void addNewsletter(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String email = request.getParameter("email");
            
            if (email == null || email.trim().isEmpty()) {
                response.sendRedirect("newsletters?error=empty");
                return;
            }
            
            email = email.trim().toLowerCase();
            
            // Validate email
            if (!isValidEmail(email)) {
                response.sendRedirect("newsletters?error=invalid");
                return;
            }
            
            boolean success = newsletterDAO.subscribe(email);
            
            if (success) {
                response.sendRedirect("newsletters?success=added");
            } else {
                response.sendRedirect("newsletters?error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("newsletters?error=exception");
        }
    }
    
    /**
     * Xóa newsletter
     */
    private void deleteNewsletter(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String email = request.getParameter("email");
            
            if (email == null || email.trim().isEmpty()) {
                response.sendRedirect("newsletters?error=invalid");
                return;
            }
            
            boolean success = newsletterDAO.deleteNewsletter(email);
            
            if (success) {
                response.sendRedirect("newsletters?success=deleted");
            } else {
                response.sendRedirect("newsletters?error=cannotdelete");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("newsletters?error=exception");
        }
    }
    
    /**
     * Bật/tắt trạng thái newsletter
     */
    private void toggleStatus(HttpServletRequest request, HttpServletResponse response) 
            throws ServletException, IOException {
        
        try {
            String email = request.getParameter("email");
            String status = request.getParameter("status");
            
            if (email == null || status == null) {
                response.sendRedirect("newsletters?error=invalid");
                return;
            }
            
            boolean success;
            if ("enable".equals(status)) {
                success = newsletterDAO.subscribe(email);
            } else {
                success = newsletterDAO.unsubscribe(email);
            }
            
            if (success) {
                response.sendRedirect("newsletters?success=updated");
            } else {
                response.sendRedirect("newsletters?error=failed");
            }
            
        } catch (Exception e) {
            e.printStackTrace();
            response.sendRedirect("newsletters?error=exception");
        }
    }
    
    /**
     * Validate email format
     */
    private boolean isValidEmail(String email) {
        String emailRegex = "^[A-Za-z0-9+_.-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,}$";
        return email.matches(emailRegex);
    }
}