package Serverlet;

import java.io.IOException;
import java.sql.Date;

import DAO.UserDAO;
import Model.User;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.mindrot.jbcrypt.BCrypt;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    UserDAO dao = new UserDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");

        try {
            String fullname = req.getParameter("fullname");
            String email = req.getParameter("email");
            String mobile = req.getParameter("mobile");
            String password = req.getParameter("password");
            String confirm = req.getParameter("confirm");
            String genderParam = req.getParameter("gender");
            String birthdayParam = req.getParameter("birthday");

            // DEBUG INPUT
            System.out.println("=== DEBUG REGISTER ===");
            System.out.println("fullname = " + fullname);
            System.out.println("email = " + email);
            System.out.println("mobile = " + mobile);
            System.out.println("password = " + password);
            System.out.println("confirm = " + confirm);
            System.out.println("gender = " + genderParam);
            System.out.println("birthday = " + birthdayParam);

            boolean gender = "male".equals(genderParam);
            Date birthday = Date.valueOf(birthdayParam);

            // Kiểm tra xác nhận mật khẩu
            if (!password.equals(confirm)) {
                System.out.println("Lỗi: Mật khẩu không khớp!");
                resp.sendRedirect("register.jsp?mismatch=true");
                return;
            }

            // Kiểm tra email trùng
            if (dao.findByEmail(email) != null) {
                System.out.println("Lỗi: Email đã tồn tại!");
                resp.sendRedirect("register.jsp?exists=true");
                return;
            }

            // Hash mật khẩu
            String hashed = BCrypt.hashpw(password, BCrypt.gensalt(12));

            User u = new User();
            u.setFullname(fullname);
            u.setEmail(email);
            u.setMobile(mobile);
            u.setBirthday(birthday);
            u.setGender(gender);
            u.setPassword(hashed);
            u.setRole(false); // mặc định phóng viên

            System.out.println("Tiến hành insert DB...");
            boolean ok = dao.register(u);

            System.out.println("Kết quả insert = " + ok);

            if (!ok) {
                System.out.println("Insert thất bại (DAO trả về false)");
                resp.sendRedirect("register.jsp?error=true");
                return;
            }

            resp.sendRedirect("login.jsp?success=true");

        } catch (Exception e) {
            System.out.println("=== EXCEPTION ===");
            e.printStackTrace();
            resp.sendRedirect("register.jsp?error=true");
        }
    }
}
