package Controller;

import java.io.IOException;
import java.util.List;

import Model.Country;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet("/bai2")
public class Bai2_Controller extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        List<Country> list = List.of(
            new Country("VN", "Việt Nam"),
            new Country("US", "United States"),
            new Country("CN", "China")
        );

        req.setAttribute("countries", list);
        req.getRequestDispatcher("/Bai2.jsp").forward(req, resp);
    }
}
